import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Player, PlayerRef } from '@remotion/player';
import { CinematicDemo, resolveSrc } from '../remotion/CinematicDemo';
import { defaultProject } from '../remotion/defaults';
import { applyLook, retime } from '../remotion/presets';
import { CAPTION_STYLES, DemoProject, DEVICES, dimensions, FORMATS, FPS, isPhone, WALLPAPERS, type Format } from '../remotion/types';
import { getRender, probeAspect, probeDuration, RenderJob, startRender, uploadFile, waveformPeaks } from './api';
import { Icon } from './icons';
import { ExportQuestion, FeedbackButton } from './Feedback';
import { CopyLink } from './Watch';
import { Inspector } from './Inspector';
import { Selection, Timeline } from './Timeline';
import { AccountMenu, api, useAccount } from './account';
import { TEMPLATES } from '../remotion/templates';
import { onBeat } from '../remotion/music';
import { analyzeBeats, snapToBeat } from './beats';
import { newShot } from '../remotion/shots/library';
import { filmCheck, type FilmNote } from '../remotion/shots/check';
import { zoomsFromMotion, type MotionEvent } from '../remotion/autozoom';
import { canRecord, Recorder, type Recording } from './Recorder';

const STORE = 'lumora.project.v1';
// A look (and extra effects as JSON) can come in the link, e.g. from the landing-page look lab.
type LinkOpts = { look?: string; fx?: string; device?: string; captions?: string; backdrop?: string };
const load = (template: string | undefined, o: LinkOpts): DemoProject => {
  const p = withExtras(loadBase(template), o);
  const { look, fx } = o;
  if (!look) return p;
  const styled = applyLook(p, look);
  try {
    return fx ? { ...styled, effects: { ...styled.effects, ...JSON.parse(fx) } } : styled;
  } catch {
    return styled;
  }
};
// Device and captions picked in the landing-page look lab
const withExtras = (p: DemoProject, o: LinkOpts): DemoProject => ({
  ...p,
  device: DEVICES.some((d) => d.key === o.device) ? (o.device as DemoProject['device']) : p.device,
  captions: CAPTION_STYLES.some((c) => c.key === o.captions) ? (o.captions as DemoProject['captions']) : p.captions,
  backdrop: WALLPAPERS.find((w) => w.name === o.backdrop)?.src ?? p.backdrop,
});
const loadBase = (template?: string): DemoProject => {
  const tpl = TEMPLATES.find((t) => t.id === template);
  if (tpl) return onBeat(tpl.project);
  if (template === 'blank')
    return {
      ...onBeat(defaultProject),
      title: 'Your product',
      tagline: 'Say what it does in one line.',
      focusType: { ...defaultProject.focusType, text: 'Meet your product' },
      callouts: defaultProject.callouts.map((c, i) => ({ ...c, text: i === 0 ? 'Your best feature' : 'Why people love it' })),
    };
  try {
    const raw = localStorage.getItem(STORE);
    if (raw) return { ...defaultProject, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return onBeat(defaultProject);
};

const uid = () => Math.random().toString(36).slice(2, 9);

type SaveState = 'local' | 'saving' | 'saved' | 'unsaved' | 'error';

const mod = typeof navigator !== 'undefined' && /Mac|iP/.test(navigator.platform) ? '⌘' : 'Ctrl';
const SHORTCUTS: [string, string][] = [
  ['Space', 'Play / pause'],
  ['← →', 'Previous / next frame'],
  ['Shift ←', 'Jump one second (with → too)'],
  ['K', 'Add a camera keyframe at the playhead'],
  ['C', 'Add a callout at the playhead'],
  ['Z', 'Add a zoom-in at the playhead'],
  [`${mod} Z`, 'Undo'],
  [`${mod} Shift Z`, 'Redo'],
  [`${mod} S`, 'Save project'],
  ['1 – 5', 'Settings tabs: Story, Look, Motion, Sound, Finish'],
  ['/', 'Find a setting'],
  ['Esc', 'Back to the project settings'],
  ['?', 'Show this list'],
];

// What the preview shows when a frame throws, instead of the Player's bare ⚠️.
const PlayerError: React.FC<{ error: Error; onShown: (e: Error) => void; onRetry: () => void }> = ({ error, onShown, onRetry }) => {
  useEffect(() => onShown(error), [error]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="player-error">
      <strong>This frame could not be drawn</strong>
      <span>{error.message}</span>
      <button onClick={onRetry}>Try again</button>
    </div>
  );
};

export const App: React.FC<{ projectId?: string; template?: string; record?: boolean } & LinkOpts> = ({ projectId: initialId, template, record, ...link }) => {
  const account = useAccount();
  const [project, setProject] = useState<DemoProject>(() => load(template, link));
  const [projectId, setProjectId] = useState<string | undefined>(initialId);
  const [name, setName] = useState(() => TEMPLATES.find((t) => t.id === template)?.project.title ?? 'Untitled video');
  // Until the user renames the project, its name follows the video title.
  const [nameTouched, setNameTouched] = useState(!!projectId);
  const [saveState, setSaveState] = useState<SaveState>(initialId ? 'saved' : 'local');
  const past = useRef<DemoProject[]>([]);
  const future = useRef<DemoProject[]>([]);
  const pending = useRef<DemoProject | null>(null);
  const [, force] = useState(0);
  const projectRef = useRef(project);
  projectRef.current = project;

  const update = useCallback((fn: (p: DemoProject) => DemoProject, commitNow = false) => {
    const cur = projectRef.current;
    if (!pending.current) pending.current = cur;
    const next = fn(cur);
    projectRef.current = next;
    setProject(next);
    if (commitNow) {
      past.current.push(pending.current);
      pending.current = null;
      future.current = [];
      force((n) => n + 1);
    }
  }, []);
  const commit = useCallback(() => {
    if (!pending.current) return;
    past.current.push(pending.current);
    pending.current = null;
    future.current = [];
    force((n) => n + 1);
  }, []);
  const undo = useCallback(() => {
    const prev = past.current.pop();
    if (!prev) return;
    future.current.push(projectRef.current);
    setProject(prev);
    force((n) => n + 1);
  }, []);
  const redo = useCallback(() => {
    const next = future.current.pop();
    if (!next) return;
    past.current.push(projectRef.current);
    setProject(next);
    force((n) => n + 1);
  }, []);

  useEffect(() => {
    const id = setTimeout(() => localStorage.setItem(STORE, JSON.stringify(project)), 300);
    return () => clearTimeout(id);
  }, [project]);

  // Open a saved project
  const loaded = useRef(false);
  useEffect(() => {
    if (!initialId || account.loading) return;
    if (!account.me) {
      account.requireAuth('Sign in to open this project.');
      return;
    }
    api
      .get<{ name: string; data: DemoProject }>(`/api/projects/${initialId}`)
      .then((r) => {
        setProject({ ...defaultProject, ...r.data });
        setName(r.name);
        setSaveState('saved');
        loaded.current = true;
      })
      .catch(() => setSaveState('error'));
  }, [initialId, account.loading, account.me]); // eslint-disable-line react-hooks/exhaustive-deps

  // Save to the account (first save asks to sign in), then autosave while editing
  const save = useCallback(async () => {
    const m = await account.requireAuth('Create a free account to save your project and export videos.');
    if (!m) return;
    setSaveState('saving');
    try {
      const p = projectRef.current;
      const thumb = p.media.kind === 'image' ? p.media.slides?.[0] ?? p.media.src : undefined;
      const r = await api.post<{ id: string }>('/api/projects', { id: projectId, name, data: p, thumb });
      if (r.id !== projectId) {
        setProjectId(r.id);
        history.replaceState(null, '', `#/editor?project=${r.id}`);
      }
      setSaveState('saved');
    } catch {
      setSaveState('error');
    }
  }, [account, projectId, name]);
  const firstRender = useRef(true);
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    if (!projectId || !account.me) {
      setSaveState((s) => (s === 'local' ? 'local' : 'unsaved'));
      return;
    }
    if (initialId && !loaded.current) return;
    setSaveState('unsaved');
    const t = setTimeout(save, 1500);
    return () => clearTimeout(t);
  }, [project, name]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!nameTouched && project.title.trim()) setName(project.title.trim());
  }, [project.title, nameTouched]);

  // Back from checkout
  const [notice, setNotice] = useState<string | null>(template === 'blank' ? 'Drop your screen recording or screenshots anywhere, or press Upload recording.' : null);
  useEffect(() => {
    const show = (plan: string) => {
      setNotice(`You're on ${plan[0].toUpperCase()}${plan.slice(1)} now: 1080p exports without watermark.`);
      setTimeout(() => setNotice(null), 6000);
    };
    const m = location.hash.match(/upgraded=(\w+)/);
    if (m) {
      show(m[1]);
      account.refresh();
    }
    const on = (e: Event) => show((e as CustomEvent<string>).detail);
    window.addEventListener('lumora:upgraded', on);
    return () => window.removeEventListener('lumora:upgraded', on);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const dims = dimensions(project);
  // Player state
  const player = useRef<PlayerRef>(null);
  const [frame, setFrame] = useState(() => Math.round(FPS * 4.6));
  const [playing, setPlaying] = useState(false);
  // A frame that throws leaves the Player on its error screen for good, so it is
  // remounted (at the same frame) on the next edit or when the person retries.
  const [playerKey, setPlayerKey] = useState(0);
  const [playerError, setPlayerError] = useState(false);
  const resumeAt = useRef(frame);
  const retryPlayer = useCallback(() => {
    resumeAt.current = frame;
    setPlayerError(false);
    setPlaying(false);
    setPlayerKey((k) => k + 1);
  }, [frame]);
  // the fallback reports it: the Player's 'error' event fires before a listener is attached
  // when the very first frame throws
  const onPlayerError = useCallback((error: Error) => {
    console.error('Preview frame failed', error);
    setPlayerError(true);
    setPlaying(false);
  }, []);
  useEffect(() => {
    const p = player.current;
    if (!p) return;
    const onFrame = (e: { detail: { frame: number } }) => setFrame(e.detail.frame);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    p.addEventListener('frameupdate', onFrame);
    p.addEventListener('seeked', onFrame);
    p.addEventListener('play', onPlay);
    p.addEventListener('pause', onPause);
    p.addEventListener('ended', onPause);
    return () => {
      p.removeEventListener('frameupdate', onFrame);
      p.removeEventListener('seeked', onFrame);
      p.removeEventListener('play', onPlay);
      p.removeEventListener('pause', onPause);
      p.removeEventListener('ended', onPause);
    };
  }, [playerKey]);
  const durationInFrames = Math.max(1, Math.round(project.duration * FPS));
  const seek = useCallback((t: number) => {
    const f = Math.max(0, Math.min(durationInFrames - 1, Math.round(t * FPS)));
    player.current?.seekTo(f);
    setFrame(f);
  }, [durationInFrames]);
  const togglePlay = useCallback(() => player.current?.toggle(), []);

  const [selection, setSelection] = useState<Selection>({ type: 'project' });
  const time = frame / FPS;

  // Waveform for the score track
  const [peaks, setPeaks] = useState<number[]>([]);
  useEffect(() => {
    if (project.score.src) waveformPeaks(resolveSrc(project.score.src)).then(setPeaks);
  }, [project.score.src]);

  const setDuration = useCallback((d: number) => update((q) => retime(q, d), true), [update]);

  // Upload
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const handleFiles = useCallback(
    async (list: FileList | File[]) => {
      const files = Array.from(list);
      const images = files.filter((f) => f.type.startsWith('image'));
      try {
        setError(null);
        setNotice(null);
        // Several screenshots at once become a slideshow
        if (images.length > 1) {
          setBusy(`Uploading ${images.length} screenshots…`);
          const ups = await Promise.all(images.map(uploadFile));
          update((q) => ({ ...q, media: { src: ups[0].url, kind: 'image', slides: ups.map((u) => u.url) } }), true);
        }
        for (const file of files) {
          if (images.length > 1 && file.type.startsWith('image')) continue;
          setBusy(`Uploading ${file.name}…`);
          const dur = file.type.startsWith('image') ? 0 : await probeDuration(file);
          const up = await uploadFile(file);
          const length = dur || up.duration;
          if (up.kind === 'audio') {
            update((q) => ({ ...q, score: { ...q.score, src: up.url, name: file.name.replace(/\.[^.]+$/, '').slice(0, 24), duration: q.duration, start: 0, bpm: undefined, beats: undefined } }), true);
            // land the edit on the new track's beat
            setBusy('Finding the beat…');
            const info = await analyzeBeats(up.url);
            if (info) update((q) => snapToBeat(q, info), true);
          } else {
            // a portrait recording is a phone app: put it in a phone, and take landscape ones back out
            const aspect = await probeAspect(file);
            const portrait = aspect > 0 && aspect < 0.75;
            const landscape = aspect > 1.1;
            const cur = projectRef.current.device;
            const device = portrait && !isPhone(cur) ? 'iphone' : landscape && isPhone(cur) ? undefined : cur;
            if (device !== cur) {
              setNotice(device ? 'Portrait screen, so it is now in an iPhone. Change it under Device.' : 'Landscape screen, so it is out of the phone frame. Change it under Device.');
              setTimeout(() => setNotice(null), 6000);
            }
            update((q) => {
              let next: DemoProject = { ...q, device, media: { src: up.url, kind: up.kind as 'image' | 'video', length: length || undefined } };
              if (up.kind === 'video' && length > 0) next = retime(next, Math.max(5, Math.min(60, Math.round(length))));
              return next;
            }, true);
            if (up.kind === 'video') {
              // zoom in where things happen, like recorders that follow the cursor
              setBusy('Finding where the action is…');
              const found = await api.post<{ events: MotionEvent[] }>('/api/media/motion', { src: up.url }).catch(() => null);
              const zooms = found ? zoomsFromMotion(projectRef.current, found.events) : [];
              if (zooms.length) {
                update((q) => ({ ...q, zooms, effects: { ...q.effects, motionBlur: true } }), true);
                setNotice(`Added ${zooms.length} zoom${zooms.length > 1 ? 's' : ''} where things happen on screen. Move or delete them on the timeline.`);
                setTimeout(() => setNotice(null), 7000);
              }
            }
          }
        }
      } catch (e) {
        setError((e as Error).message);
      } finally {
        setBusy(null);
      }
    },
    [update],
  );
  const [dragging, setDragging] = useState(false);
  useEffect(() => {
    const over = (e: DragEvent) => {
      e.preventDefault();
      setDragging(true);
    };
    const leave = (e: DragEvent) => {
      if (!e.relatedTarget) setDragging(false);
    };
    const drop = (e: DragEvent) => {
      e.preventDefault();
      setDragging(false);
      if (e.dataTransfer?.files.length) handleFiles(e.dataTransfer.files);
    };
    window.addEventListener('dragover', over);
    window.addEventListener('dragleave', leave);
    window.addEventListener('drop', drop);
    return () => {
      window.removeEventListener('dragover', over);
      window.removeEventListener('dragleave', leave);
      window.removeEventListener('drop', drop);
    };
  }, [handleFiles]);

  // Adding things at the playhead
  const onAdd = useCallback(
    (what: 'callout' | 'keyframe' | 'section' | 'zoom' | 'shot') => {
      const t = +time.toFixed(2);
      if (what === 'callout') {
        const id = uid();
        update((q) => ({ ...q, callouts: [...q.callouts, { id, start: t, duration: Math.min(2, q.duration - t), text: 'New callout', x: 0.5, y: 0.4 }] }), true);
        setSelection({ type: 'callout', id });
      }
      if (what === 'zoom') {
        const id = uid();
        update((q) => ({ ...q, zooms: [...(q.zooms ?? []), { id, start: t, duration: Math.max(1.2, Math.min(2.5, q.duration - t)), x: 0.5, y: 0.45, scale: 1.8 }] }), true);
        setSelection({ type: 'zoom', id });
      }
      if (what === 'shot') {
        const shot = newShot(projectRef.current, 'headline', Math.min(t, Math.max(0, projectRef.current.duration - 1)));
        update((q) => ({ ...q, shots: [...(q.shots ?? []), shot] }), true);
        setSelection({ type: 'shot', id: shot.id });
      }
      if (what === 'keyframe') {
        const q = projectRef.current;
        const sorted = [...q.camera].sort((a, b) => a.t - b.t);
        const near = sorted.reduce((a, b) => (Math.abs(b.t - t) < Math.abs(a.t - t) ? b : a));
        update((x) => ({ ...x, camera: [...x.camera, { ...near, t }] }), true);
        setSelection({ type: 'camera', index: q.camera.length });
      }
      if (what === 'section') {
        const id = uid();
        const colors = ['#f43f5e', '#f59e0b', '#10b981', '#6366f1', '#ec4899'];
        update((q) => ({ ...q, sections: [...q.sections, { id, name: 'Beat', start: t, color: colors[q.sections.length % colors.length] }] }), true);
        setSelection({ type: 'section', id });
      }
    },
    [time, update],
  );

  // Keyboard shortcuts
  const [help, setHelp] = useState(false);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowLeft') seek(time - (e.shiftKey ? 1 : 1 / FPS));
      else if (e.key === 'ArrowRight') seek(time + (e.shiftKey ? 1 : 1 / FPS));
      else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
      } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        save();
      } else if (e.key === 'k') onAdd('keyframe');
      else if (e.key === 'c') onAdd('callout');
      else if (e.key === 'z' && !e.metaKey && !e.ctrlKey) onAdd('zoom');
      else if (e.key === '?') setHelp((h) => !h);
      else if (e.key === 'Escape') {
        setHelp(false);
        setSelection({ type: 'project' });
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlay, seek, time, undo, redo, onAdd, save]);

  // Recorded in the browser: the screen goes in like an upload (auto zoom included), the webcam
  // becomes the corner bubble, and with the microphone on its words become captions.
  const [recording, setRecording] = useState(!!record && canRecord());
  const applyRecording = async (r: Recording) => {
    await handleFiles([r.screen]);
    try {
      if (r.cam) {
        setBusy('Adding your webcam…');
        const up = await uploadFile(r.cam);
        update((q) => ({ ...q, cam: { corner: 'bl', size: 0.26, shape: 'circle', src: up.url } }), true);
      }
      if (r.mic) {
        update((q) => ({ ...q, media: { ...q.media, sound: 1 } }), true);
        const speech = await api.get<{ speech?: string | null }>('/api/voices').then((v) => v.speech).catch(() => null);
        if (speech && account.me) {
          setBusy('Captioning what you said…');
          const p0 = projectRef.current;
          const t = await api.post<{ words: { text: string; startMs: number; endMs: number }[] }>('/api/media/transcribe', { src: p0.media.src, hint: [p0.title, p0.tagline].filter(Boolean).join('. ') }).catch(() => null);
          if (t?.words.length) update((q) => ({ ...q, media: { ...q.media, words: t.words }, captions: q.captions ?? 'clean' }), true);
        }
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(null);
    }
  };

  // Export
  const [job, setJob] = useState<RenderJob | null>(null);
  const [exportFormat, setExportFormat] = useState<'mp4' | 'mp4-4k' | 'mp4-all' | 'mp4-nomusic' | 'mp4-pack' | 'gif' | 'webm'>('mp4');
  // one edit, three shapes: 16:9, 9:16 and 1:1 rendered side by side
  const [batch, setBatch] = useState<{ format: Format; job: RenderJob }[] | null>(null);
  const exportAll = async () => {
    const shapes: Format[] = ['landscape', 'vertical', 'square'];
    const started: { format: Format; job: RenderJob }[] = [];
    for (const format of shapes) {
      try {
        const id = await startRender({ ...projectRef.current, format, projectId, exportFormat: 'mp4' });
        started.push({ format, job: { id, status: 'queued', progress: 0 } });
      } catch (e) {
        const err = e as Error & { upgrade?: boolean };
        started.push({ format, job: { id: '', status: 'error', progress: 0, error: err.message } });
        if (err.upgrade) break;
      }
    }
    setBatch(started);
    const poll = async () => {
      const next = await Promise.all(started.map(async (b) => (b.job.id && b.job.status !== 'done' && b.job.status !== 'error' ? { ...b, job: await getRender(b.job.id) } : b)));
      started.splice(0, started.length, ...next);
      setBatch([...next]);
      if (next.some((b) => b.job.status !== 'done' && b.job.status !== 'error')) setTimeout(poll, 1000);
      else account.refresh();
    };
    poll();
  };
  // things that look broken in the video, shown once before an export
  const [preflight, setPreflight] = useState<FilmNote[] | null>(null);
  const exportVideo = async (anyway = false) => {
    try {
      setError(null);
      const m = await account.requireAuth('Create a free account to export your video. Free includes 3 exports a month.');
      if (!m) return;
      const fixes = filmCheck(projectRef.current).filter((n) => n.level === 'fix');
      if (fixes.length && !anyway) return void setPreflight(fixes);
      setPreflight(null);
      player.current?.pause();
      if (exportFormat === 'mp4-all') return void (await exportAll());
      const mp4 = exportFormat.startsWith('mp4');
      const id = await startRender({ ...projectRef.current, projectId, exportFormat: mp4 ? 'mp4' : (exportFormat as 'gif' | 'webm'), quality: exportFormat === 'mp4-4k' ? '4k' : 'hd', music: exportFormat !== 'mp4-nomusic', pack: exportFormat === 'mp4-pack' });
      setJob({ id, status: 'queued', progress: 0 });
      const poll = async () => {
        const j = await getRender(id);
        setJob(j);
        if (j.status !== 'done' && j.status !== 'error') setTimeout(poll, 700);
        else account.refresh();
      };
      poll();
    } catch (e) {
      const err = e as Error & { upgrade?: boolean };
      if (err.upgrade) account.openUpgrade(err.message);
      else setError(err.message);
    }
  };

  // Hovering a look, device or style in the inspector previews it here; any real edit ends it.
  const [peek, setPeek] = useState<{ project: DemoProject; label: string } | null>(null);
  const peekTimer = useRef<number | undefined>(undefined);
  const onPeek = useCallback((fn: ((p: DemoProject) => DemoProject) | null, label = '') => {
    window.clearTimeout(peekTimer.current);
    // a short wait, so sweeping the mouse over a grid doesn't redraw every choice it crosses
    peekTimer.current = window.setTimeout(() => setPeek(fn ? { project: fn(projectRef.current), label } : null), fn ? 90 : 120);
  }, []);
  useEffect(() => {
    window.clearTimeout(peekTimer.current);
    setPeek(null);
  }, [project]);
  const inputProps = useMemo(() => peek?.project ?? project, [project, peek]);
  // an edit (a new screenshot, say) gets a fresh Player instead of the stale error screen
  useEffect(() => {
    if (playerError) retryPlayer();
  }, [inputProps]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="app">
      <header className="topbar">
        <a className="brand" href="#/" style={{ textDecoration: 'none', color: 'inherit' }}>
          <span className="brand-mark" />
          Lumora
        </a>
        <div className="doc-title">
          <input value={name} onChange={(e) => { setNameTouched(true); setName(e.target.value); }} aria-label="Project name" />
          <span className={`save-state ${saveState}`}>
            {saveState === 'saving' ? 'Saving…' : saveState === 'saved' ? 'Saved' : saveState === 'unsaved' ? 'Unsaved changes' : saveState === 'error' ? 'Save failed' : 'Draft in this browser'}
          </span>
        </div>
        <div className="top-actions">
          <button className="ghost" title="Undo (⌘Z)" disabled={!past.current.length} onClick={undo}><Icon.undo /></button>
          <button className="ghost" title="Redo (⇧⌘Z)" disabled={!future.current.length} onClick={redo}><Icon.redo /></button>
          <button className="ghost" title="Keyboard shortcuts (?)" onClick={() => setHelp(true)} style={{ fontWeight: 700, minWidth: 34 }}>?</button>
          <a className="ghost" href="#/projects">Projects</a>
          <FeedbackButton />
          <button className="ghost" onClick={save} title="Save (⌘S)">Save</button>
          {canRecord() && (
            <button className="secondary" title="Record your screen, webcam and voice in the browser" onClick={() => setRecording(true)}>
              <Icon.record /> Record
            </button>
          )}
          <button className="secondary" onClick={() => fileInput.current?.click()}>
            <Icon.upload /> Upload recording
          </button>
          <input
            ref={fileInput}
            type="file"
            hidden
            multiple
            accept="image/*,video/*,audio/*"
            onChange={(e) => {
              if (e.target.files) handleFiles(e.target.files);
              e.target.value = '';
            }}
          />
          <span className="export-group">
            <button className="primary" onClick={() => exportVideo()} disabled={!!job && job.status !== 'done' && job.status !== 'error'}>
              <Icon.sparkle /> Export {exportFormat === 'mp4-4k' ? '4K' : exportFormat === 'mp4-all' ? 'all sizes' : exportFormat === 'mp4-nomusic' ? 'MP4' : exportFormat === 'mp4-pack' ? 'package' : exportFormat.toUpperCase()}
            </button>
            <select aria-label="Export format" value={exportFormat} onChange={(e) => setExportFormat(e.target.value as typeof exportFormat)}>
              <option value="mp4">MP4 · video with sound</option>
              <option value="mp4-4k">MP4 4K · Pro, takes longer</option>
              <option value="mp4-all">MP4 in 16:9, 9:16 and 1:1 · uses 3 exports</option>
              <option value="mp4-nomusic">MP4 without music · add your own later</option>
              <option value="mp4-pack">Editing package · clips, audio stems, captions (.zip)</option>
              <option value="gif">GIF · README, X, Product Hunt</option>
              <option value="webm">WebM · websites</option>
            </select>
          </span>
          <AccountMenu />
        </div>
      </header>

      <main className="workspace">
        <section className="stage">
          <div className={`stage-frame ${project.format ?? 'landscape'}`}>
            <Player
              key={playerKey}
              ref={player}
              component={CinematicDemo}
              inputProps={inputProps}
              durationInFrames={durationInFrames}
              fps={FPS}
              compositionWidth={dims.width}
              compositionHeight={dims.height}
              style={{ width: '100%', aspectRatio: `${dims.width} / ${dims.height}` }}
              loop
              clickToPlay
              acknowledgeRemotionLicense
              initialFrame={Math.min(durationInFrames - 1, resumeAt.current)}
              errorFallback={({ error }) => <PlayerError error={error} onShown={onPlayerError} onRetry={retryPlayer} />}
            />
          </div>
          {peek && <div className="peek-badge">Preview · <b>{peek.label}</b> <span>click to use</span></div>}
          {(busy || error || notice) && <div className={`toast ${error ? 'err' : ''}`}>{error ?? busy ?? notice}</div>}
        </section>
        <aside className="side">
          <Inspector project={project} update={update} selection={selection} select={setSelection} setDuration={setDuration} onUpload={() => fileInput.current?.click()} seek={seek} peek={onPeek} />
        </aside>
      </main>

      <Timeline
        project={project}
        update={update}
        commit={commit}
        time={time}
        playing={playing}
        seek={seek}
        togglePlay={togglePlay}
        selection={selection}
        select={setSelection}
        peaks={peaks}
        onAdd={onAdd}
      />

      {dragging && (
        <div className="dropzone">
          <div>
            <Icon.upload size={42} />
            <h2>Drop your screen recording</h2>
            <p>Video or screenshot becomes the hero shot. Audio becomes the score.</p>
          </div>
        </div>
      )}

      {recording && <Recorder onClose={() => setRecording(false)} onDone={(r) => { setRecording(false); applyRecording(r); }} />}
      {help && (
        <div className="modal" onClick={() => setHelp(false)}>
          <div className="modal-card shortcuts" onClick={(e) => e.stopPropagation()}>
            <h2>Keyboard shortcuts</h2>
            <dl>
              {SHORTCUTS.map(([k, d]) => (
                <React.Fragment key={k}>
                  <dt>{k.split(' ').map((x) => <kbd key={x}>{x}</kbd>)}</dt>
                  <dd>{d}</dd>
                </React.Fragment>
              ))}
            </dl>
            <div className="modal-actions"><button className="ghost" onClick={() => setHelp(false)}>Close</button></div>
          </div>
        </div>
      )}

      <div className="mobile-note">The editor works best on a laptop or desktop. You can still preview and export here.</div>

      {batch && (
        <div className="modal" onClick={() => batch.every((b) => b.job.status === 'done' || b.job.status === 'error') && setBatch(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <h2>{batch.every((b) => b.job.status === 'done') ? 'All three sizes are ready' : 'Rendering three sizes'}</h2>
            <div className="batch">
              {batch.map((b) => (
                <div key={b.format} className="batch-row">
                  <b>{FORMATS[b.format].label}</b>
                  <span className="note">{FORMATS[b.format].hint}</span>
                  {b.job.status === 'done' && b.job.url ? (
                    <a className="primary" href={b.job.url} download={`lumora-${b.format}.mp4`}><Icon.download /> MP4</a>
                  ) : b.job.status === 'error' ? (
                    <span className="note err">{b.job.error}</span>
                  ) : (
                    <div className="progress"><div style={{ width: `${Math.round(b.job.progress * 100)}%` }} /></div>
                  )}
                </div>
              ))}
            </div>
            <div className="modal-actions"><button className="ghost" onClick={() => setBatch(null)}>Close</button></div>
          </div>
        </div>
      )}
      {preflight && (
        <div className="modal" onClick={() => setPreflight(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <h2>Before you export</h2>
            <p className="note">The final check found {preflight.length === 1 ? 'one thing' : `${preflight.length} things`} a viewer would notice.</p>
            <ul className="copy-notes film-notes">
              {preflight.slice(0, 6).map((n, i) => (
                <li key={i} className="fix"><b>{n.where}</b> {n.tip}</li>
              ))}
            </ul>
            <div className="modal-actions">
              <button className="ghost" onClick={() => exportVideo(true)}>Export anyway</button>
              <button className="primary" onClick={() => { const n = preflight[0]; setPreflight(null); if (n.at !== undefined) player.current?.seekTo(Math.round(n.at * FPS)); if (n.shot) setSelection({ type: 'shot', id: n.shot }); }}>Fix it first</button>
            </div>
          </div>
        </div>
      )}
      {job && (
        <div className="modal" onClick={() => (job.status === 'done' || job.status === 'error') && setJob(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            {job.status === 'done' && job.url ? (
              <>
                <h2>Your video is ready</h2>
                {job.url?.endsWith('.gif') ? <img src={job.url} alt="" className="result" /> : <video src={job.url} controls autoPlay loop className="result" />}
                <div className="modal-actions">
                  <button className="ghost" onClick={() => setJob(null)}>Close</button>
                  <CopyLink id={job.id} />
                  {job.srt && <a className="ghost" href={job.srt} download="lumora-demo.srt"><Icon.download /> Captions .srt</a>}
                  {job.pack && <a className="ghost" href={job.pack} download="lumora-package.zip" title="Each shot as its own clip, music, sound effect and voice stems, captions and a timeline, for Premiere, Final Cut, DaVinci or CapCut"><Icon.download /> Editing package .zip</a>}
                  <a className="primary" href={job.url} download={`lumora-demo.${job.url?.split('.').pop()}`}><Icon.download /> Download {job.url?.split('.').pop()?.toUpperCase()}</a>
                </div>
                <ExportQuestion />
              </>
            ) : job.status === 'error' ? (
              <>
                <h2>Render failed</h2>
                <p className="note">{job.error}</p>
                <div className="modal-actions"><button className="ghost" onClick={() => setJob(null)}>Close</button></div>
              </>
            ) : (
              <>
                <h2>{job.status === 'packing' ? 'Cutting clips and audio stems' : job.status === 'rendering' ? 'Rendering your video' : job.ahead ? 'Waiting in line' : 'Preparing render'}</h2>
                {job.status === 'queued' && !!job.ahead && (
                  <p className="note">{job.ahead === 1 ? '1 video is' : `${job.ahead} videos are`} ahead of yours. You can keep editing, and the video will open here when it is ready.</p>
                )}
                <div className="progress"><div style={{ width: `${Math.round(job.progress * 100)}%` }} /></div>
                <p className="note">
                  {Math.round(job.progress * 100)}% · {account.me?.limits.label ?? '1080p'}, 30 fps
                  {account.me?.plan === 'free' && (
                    <>
                      {' · '}
                      <button className="link" onClick={() => account.openUpgrade()}>Upgrade for 1080p without watermark</button>
                    </>
                  )}
                </p>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
