import React, { useContext, useEffect, useRef, useState } from 'react';
import { CAM_CORNERS, CALLOUT_STYLES, CameraKey, CAPTION_STYLES, DemoProject, DEVICES, DROP_STYLES, Effects, EFFECTS, Format, fxOn, SFX_STYLES, SHOT_TRANSITIONS, type Shot, FORMATS, isPhone, PALETTES, paletteOf, TEXT_STYLES, WALLPAPERS } from '../remotion/types';
import { narrationStart, toSrt } from '../remotion/narration';
import { api, useAccount } from './account';
import { BrandKitField } from './Team';
import { zoomsFromMotion, type MotionEvent } from '../remotion/autozoom';
import { copyNotes } from '../remotion/copy';
import { cleanSegments, cutRanges, deadEnds, isFiller, keptSeconds, restoreRanges, speedUpStill, tightenPauses, toTimeline, wordsRange, type Segment } from '../remotion/segments';
import { analyzeBeats, snapToBeat } from './beats';
import { launchFilm, newShot, SHOT_KINDS } from '../remotion/shots/library';
import { fromWebsite, type WebsiteCapture } from '../remotion/website';
import { filmCheck } from '../remotion/shots/check';
import { applyDirection, applyLook, CAMERA_STYLES, cameraForStyle, LOOKS, shuffleDirection } from '../remotion/presets';
import { autoDirect, uploadFile } from './api';
import { resolveSrc } from '../remotion/CinematicDemo';
import { beatInfo, TRACKS, withTrack, type Track } from '../remotion/music';
import type { Selection } from './Timeline';
import { Icon } from './icons';

type Props = {
  project: DemoProject;
  update: (fn: (p: DemoProject) => DemoProject, commit?: boolean) => void;
  selection: Selection;
  select: (s: Selection) => void;
  setDuration: (d: number) => void;
  onUpload: () => void;
  seek?: (t: number) => void;
  peek?: Peek;
};

// Hovering a choice shows it on the preview without changing the project; leaving puts the
// project back and a click applies it. App owns the preview, the pickers only describe it.
export type Peek = (fn: ((p: DemoProject) => DemoProject) | null, label?: string) => void;
const PeekContext = React.createContext<Peek>(() => {});
const usePeek = () => {
  const peek = useContext(PeekContext);
  return (label: string, fn: (p: DemoProject) => DemoProject) => ({
    onPointerEnter: (e: React.PointerEvent) => e.pointerType === 'mouse' && peek(fn, label),
    onPointerLeave: () => peek(null),
  });
};

const SPEEDS = [1, 1.5, 2, 3];
const PART_SPEEDS = [0.5, 1, 2, 4, 8];
// Applies on Enter or when leaving the field, so half-typed numbers don't reshuffle the parts.
const PartTime: React.FC<{ value: number; max: number; onCommit: (v: number) => void; label: string }> = ({ value, max, onCommit, label }) => (
  <input
    key={value}
    type="number"
    step={0.1}
    min={0}
    max={max}
    defaultValue={value}
    aria-label={label}
    onBlur={(e) => Number(e.target.value) !== value && onCommit(Number(e.target.value))}
    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
  />
);

// Cut a screen recording into the parts worth keeping, each at its own speed. Simple mode
// (one start point, one speed) until the person splits it or speeds up the still parts.
const RecordingTrim: React.FC<{ project: DemoProject; set: (fn: (p: DemoProject) => DemoProject) => void; update: (fn: (p: DemoProject) => DemoProject, commit?: boolean) => void; setDuration: (d: number) => void }> = ({ project: p, set, update, setDuration }) => {
  const { requireAuth } = useAccount();
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const length = p.media.length ?? 0;
  const trim = p.media.trimStart ?? 0;
  const speed = p.media.speed ?? 1;
  const parts = p.media.segments;
  const fitTo = (secs: number) => secs > 0 && setDuration(Math.max(5, Math.min(60, Math.round(secs))));
  const fit = (t: number, sp: number) => length > 0 && fitTo((length - t) / sp);
  const setParts = (next: Segment[] | undefined, fitNow = true) => {
    const clean = next ? cleanSegments(next, length) : undefined;
    update((q) => ({ ...q, media: { ...q.media, segments: clean?.length ? clean : undefined } }), true);
    if (fitNow) fitTo(keptSeconds({ ...p.media, segments: clean?.length ? clean : undefined }));
  };
  const findStill = async () => {
    if (!(await requireAuth('Sign in to find the still parts of your recording.'))) return;
    setBusy(true);
    setNote(null);
    try {
      const r = await api.post<{ length: number; still: { from: number; to: number }[] }>('/api/media/still', { src: p.media.src });
      if (!r.still.length) setNote('No still parts found: the screen keeps moving.');
      else {
        setParts(speedUpStill(r.still, r.length || length, 4));
        setNote(`Sped up ${r.still.length} still part${r.still.length > 1 ? 's' : ''} 4×.`);
      }
    } catch (e) {
      setNote((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const trimEnds = async () => {
    if (!(await requireAuth('Sign in to trim your recording.'))) return;
    setBusy(true);
    setNote(null);
    try {
      const r = await api.post<{ length: number; still: { from: number; to: number }[] }>('/api/media/still', { src: p.media.src });
      const L = r.length || length;
      const cut = deadEnds(r.still, L, p.media.words);
      if (!cut.length) setNote('Nothing to trim: the recording starts and ends with action.');
      else {
        setParts(cutRanges(p.media, cut, L));
        setNote(`Trimmed ${cut.reduce((a, c) => a + c.to - c.from, 0).toFixed(1)}s of still screen from the ${cut.length > 1 ? 'start and end' : cut[0].from === 0 ? 'start' : 'end'}.`);
      }
    } catch (e) {
      setNote((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  if (!parts?.length)
    return (
      <>
        <Field label="Start recording at" hint={length ? `of ${length.toFixed(1)}s` : 's'}>
          <Slider value={trim} min={0} max={Math.max(1, (length || 60) - 1)} step={0.1} fmt={(v) => `${v.toFixed(1)}s`} onChange={(v) => set((q) => ({ ...q, media: { ...q.media, trimStart: v } }))} />
        </Field>
        <Field label="Recording speed">
          <div className="chips">
            {SPEEDS.map((sp) => (
              <button key={sp} className={`chip ${speed === sp ? 'on' : ''}`} onClick={() => { set((q) => ({ ...q, media: { ...q.media, speed: sp } })); fit(trim, sp); }}>{sp}×</button>
            ))}
            {length > 0 && <button className="chip" title="Set the video length to the rest of the recording" onClick={() => fit(trim, speed)}>Fit length</button>}
          </div>
        </Field>
        {length > 0 && (
          <Field label="Cut and speed parts" hint="optional">
            <div className="chips">
              <button className="chip" disabled={busy} title="Cuts the still screen at the start (picking what to share) and at the end (stopping)" onClick={trimEnds}>{busy ? 'Looking…' : 'Trim dead ends'}</button>
              <button className="chip" disabled={busy} title="Finds where nothing moves and plays those parts 4× faster" onClick={findStill}>{busy ? 'Looking…' : 'Speed up still parts'}</button>
              <button className="chip" title="Cut the recording into parts you can trim and speed one by one" onClick={() => setParts([{ from: trim, to: length, speed }], false)}>Split into parts</button>
            </div>
            {note && <small className="muted">{note}</small>}
          </Field>
        )}
      </>
    );
  const L = length || Math.max(...parts.map((g) => g.to));
  const change = (i: number, patch: Partial<Segment>) => setParts(parts.map((g, j) => (j === i ? { ...g, ...patch } : g)));
  return (
    <Field label="Recording parts" hint={`${keptSeconds(p.media).toFixed(1)}s of ${L.toFixed(1)}s`}>
      <div className="parts-bar" title="Kept parts of the recording; gaps are cut">
        {parts.map((g, i) => (
          <i key={i} className={g.speed > 1 ? 'fast' : g.speed < 1 ? 'slow' : ''} style={{ left: `${(g.from / L) * 100}%`, width: `${((g.to - g.from) / L) * 100}%` }}>{g.speed !== 1 ? `${g.speed}×` : ''}</i>
        ))}
      </div>
      <div className="parts">
        {parts.map((g, i) => (
          <div key={i} className="part">
            <span className="part-n">{i + 1}</span>
            <PartTime value={g.from} max={L} onCommit={(from) => change(i, { from })} label="From second" />
            <span>–</span>
            <PartTime value={g.to} max={L} onCommit={(to) => change(i, { to })} label="To second" />
            <select value={g.speed} onChange={(e) => change(i, { speed: Number(e.target.value) })} aria-label="Speed">
              {PART_SPEEDS.map((sp) => <option key={sp} value={sp}>{sp}×</option>)}
            </select>
            <button className="mini" title="Split this part in two" onClick={() => { const mid = Math.round(((g.from + g.to) / 2) * 10) / 10; setParts([...parts.slice(0, i), { ...g, to: mid }, { ...g, from: mid }, ...parts.slice(i + 1)], false); }}><Icon.copy size={13} /></button>
            <button className="mini danger" title="Cut this part out" disabled={parts.length < 2} onClick={() => setParts(parts.filter((_, j) => j !== i))}><Icon.trash size={13} /></button>
          </div>
        ))}
      </div>
      <div className="chips">
        <button className="chip" disabled={busy} title="Cuts the still screen at the start and end" onClick={trimEnds}>{busy ? 'Looking…' : 'Trim dead ends'}</button>
        <button className="chip" disabled={busy} onClick={findStill}>{busy ? 'Looking…' : 'Speed up still parts'}</button>
        <button className="chip" onClick={() => fitTo(keptSeconds(p.media))}>Fit length</button>
        <button className="chip" title="Back to one start point and one speed" onClick={() => setParts(undefined, false)}>Undo parts</button>
      </div>
      {note && <small className="muted">{note}</small>}
      <small className="muted">Split a part, then cut the piece you don't need. Gaps between parts are left out of the video.</small>
    </Field>
  );
};

// One-click looks: camera, palette and effects together.
const LookPicker: React.FC<{ project: DemoProject; update: (fn: (p: DemoProject) => DemoProject, commit?: boolean) => void }> = ({ project: p, update }) => {
  const peek = usePeek();
  const cur = LOOKS.find((l) => l.name === p.look);
  return (
    <>
      <div className="looks">
        {LOOKS.map((l) => (
          <button key={l.name} className={`look ${p.look === l.name ? 'on' : ''}`} title={l.hint} onClick={() => update((q) => applyLook(q, l.name), true)} {...peek(l.name, (q) => applyLook(q, l.name))}>
            <span className="look-swatch" style={{ background: `linear-gradient(120deg, ${PALETTES[l.palette].join(',')})` }}>
              {l.effects.letterbox && <i className="lb" />}
              {l.effects.mono && <i className="mono" />}
            </span>
            <b>{l.name}</b>
          </button>
        ))}
      </div>
      <p className="note look-desc">{cur ? <><b>{cur.name}</b> · {cur.hint}</> : 'Your own mix. Pick a look to set camera, colour and effects together.'}</p>
      <button className="ghost wide" title="A new camera, colours, motion and effects that fit together. Your words, callouts and timing stay." onClick={() => update((q) => shuffleDirection(q), true)}>
        <Icon.shuffle size={14} /> Shuffle direction
      </button>
    </>
  );
};

// Toggles for the finishing effects, with an amount for film grain.
export const EffectsPanel: React.FC<{ project: DemoProject; set: (fn: (p: DemoProject) => DemoProject) => void }> = ({ project: p, set }) => {
  const fx = p.effects ?? {};
  const put = (patch: Partial<Effects>) => set((q) => ({ ...q, effects: { ...q.effects, ...patch } }));
  return (
    <>
      <div className="opt-grid">
          {EFFECTS.map((e) => {
            const on = fxOn(fx, e.key);
            return (
              <button key={e.key} className={`chip ${on ? 'on' : ''}`} title={e.hint} onClick={() => put({ [e.key]: e.amount ? (on ? 0 : 0.5) : !on })}>
                {e.label}
              </button>
            );
          })}
      </div>
      {fxOn(fx, 'sfx') && (
        <Group label="Sound effects">
          <div className="seg">
            {SFX_STYLES.map((st) => (
              <button key={st.key} title={st.hint} className={(p.sfxStyle ?? 'soft') === st.key ? 'on' : ''} onClick={() => set((q) => ({ ...q, sfxStyle: st.key === 'soft' ? undefined : st.key }))}>{st.label}</button>
            ))}
          </div>
        </Group>
      )}
      {!!fx.grain && (
        <Field label="Grain"><Slider value={fx.grain} min={0.05} max={1} onChange={(grain) => put({ grain })} /></Field>
      )}
    </>
  );
};

// Click on a thumbnail of the screen to set a point (used for zoom-ins).
const ZoomPicker: React.FC<{ media: DemoProject; x: number; y: number; onPick: (x: number, y: number) => void }> = ({ media: p, x, y, onPick }) => {
  const pick = (e: React.PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const c = (n: number) => Math.round(Math.max(0, Math.min(1, n)) * 100) / 100;
    onPick(c((e.clientX - r.left) / r.width), c((e.clientY - r.top) / r.height));
  };
  const src = resolveSrc(p.media.kind === 'image' && p.media.slides?.length ? p.media.slides[0] : p.media.src);
  return (
    <div className="zoom-pick" onPointerDown={pick} style={{ aspectRatio: '1500 / 940' }}>
      {p.media.kind === 'video' ? <video src={src} muted /> : <img src={src} alt="" />}
      <span className="zoom-dot" style={{ left: `${x * 100}%`, top: `${y * 100}%` }} />
    </div>
  );
};

const LogoField: React.FC<{ project: DemoProject; update: (fn: (p: DemoProject) => DemoProject, commit?: boolean) => void }> = ({ project, update }) => {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const pick = async (file?: File) => {
    if (!file) return;
    setBusy(true);
    try {
      const up = await uploadFile(file);
      update((q) => ({ ...q, logo: up.url }), true);
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Field label="Logo" hint="end card">
      <div className="logo-field">
        {project.logo ? <img src={resolveSrc(project.logo)} alt="" /> : <span className="logo-empty">No logo</span>}
        <button className="ghost" disabled={busy} onClick={() => input.current?.click()}>{busy ? 'Uploading…' : project.logo ? 'Replace' : 'Upload'}</button>
        {project.logo && <button className="mini danger" title="Remove logo" onClick={() => update((q) => ({ ...q, logo: undefined }), true)}><Icon.trash size={14} /></button>}
        <input ref={input} type="file" accept="image/png,image/svg+xml,image/webp,image/jpeg" hidden onChange={(e) => pick(e.target.files?.[0])} />
      </div>
    </Field>
  );
};

const TextStylePicker: React.FC<{ project: DemoProject; set: (fn: (q: DemoProject) => DemoProject) => void }> = ({ project: p, set }) => {
  const peek = usePeek();
  return (
    <Group label="Text animation">
      <div className="seg">
        {TEXT_STYLES.map((ts) => {
          const fn = (q: DemoProject) => ({ ...q, textStyle: ts.key === 'blur' ? undefined : ts.key });
          return <button key={ts.key} title={ts.hint} className={(p.textStyle ?? 'blur') === ts.key ? 'on' : ''} onClick={() => set(fn)} {...peek(ts.label, fn)}>{ts.label}</button>;
        })}
      </div>
    </Group>
  );
};

// A slider sits on one row with its label; anything else goes under it.
const Field: React.FC<{ label: string; children: React.ReactNode; hint?: string }> = ({ label, children, hint }) =>
  React.isValidElement(children) && children.type === Slider ? (
    <label className="field inline" title={hint}>
      <span>{label}</span>
      {children}
    </label>
  ) : (
    <label className="field">
      <span>{label}{hint && <em>{hint}</em>}</span>
      {children}
    </label>
  );

// like Field, for groups of buttons: a <label> would pass its clicks to the first button
const Group: React.FC<{ label: string; children: React.ReactNode; hint?: string }> = ({ label, children, hint }) => (
  <div className="field">
    <span>{label}{hint && <em>{hint}</em>}</span>
    {children}
  </div>
);

const Slider: React.FC<{ value: number; min: number; max: number; step?: number; onChange: (v: number) => void; fmt?: (v: number) => string }> = ({
  value,
  min,
  max,
  step = 0.01,
  onChange,
  fmt = (v) => v.toFixed(2),
}) => (
  <div className="slider">
    <input type="range" min={min} max={max} step={step} value={value} style={{ '--p': `${((Math.min(max, Math.max(min, value)) - min) / (max - min || 1)) * 100}%` } as React.CSSProperties} onChange={(e) => onChange(Number(e.target.value))} />
    <output>{fmt(value)}</output>
  </div>
);

// AI direction and AI voice are Pro and Team features: Free sees a lock, and a click opens the upgrade.
const ProLock: React.FC = () => (
  <span className="pro-lock" title="Pro and Team feature"><Icon.lock size={10} /> Pro</span>
);
const useProGate = () => {
  const { me, requireAuth, openUpgrade } = useAccount();
  const locked = !me || me.plan === 'free';
  // true when the feature may run; otherwise asks to sign in or opens the upgrade
  const unlock = async (what: string, pitch: string) => {
    const u = await requireAuth(`Create an account to use ${what}.`);
    if (!u) return false;
    if (u.plan !== 'free') return true;
    openUpgrade(`${what} is part of Pro and Team. ${pitch}`);
    return false;
  };
  return { locked, unlock };
};

const AutoDirect: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project, update }) => {
  const [brief, setBrief] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const { locked, unlock } = useProGate();
  const run = async () => {
    if (!(await unlock('AI direction', 'Describe your product in one sentence and Claude writes the copy, the voiceover script and the callouts.'))) return;
    setBusy(true);
    setMsg(null);
    try {
      const r = await autoDirect(brief, project.media);
      update((q) => applyDirection(q, r.direction), true);
      setMsg(r.source === 'claude' ? 'Directed by Claude. Tweak anything on the timeline.' : r.proOnly ? 'Quick draft from your text. AI direction is part of Pro and Team.' : r.limitReached ? "Quick draft from your text: you've used this month's 5 free AI directions. Pro has unlimited AI direction." : 'Quick draft from your text (add an Anthropic API key on the server for full AI direction).');
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="auto">
      <textarea
        rows={3}
        placeholder="What is your product and why is it great? e.g. Pulse shows live revenue, spots churn early and needs zero setup."
        value={brief}
        onChange={(e) => setBrief(e.target.value)}
      />
      <button className="primary" disabled={busy || (!locked && !brief.trim())} onClick={run}>
        {locked && <Icon.lock size={13} />}
        {busy ? 'Directing…' : 'Direct my video'}
      </button>
      {msg && <p className="note">{msg}</p>}
    </div>
  );
};

// Captures a public web page: its screens, brand colours, font, name, headline and icon.
const WebsiteField: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ update }) => {
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const run = async () => {
    setBusy(true);
    setMsg(null);
    try {
      const cap = await api.post<WebsiteCapture>('/api/capture', { url: url.trim() });
      update((q) => fromWebsite(q, cap), true);
      setMsg(`Took ${cap.sections.length} screen${cap.sections.length > 1 ? 's' : ''}, the colours, the ${cap.font} font${cap.logo ? ' and the icon' : ''} from the page.`);
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="auto">
      <input className="url-in" placeholder="yourproduct.com" value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && url.trim() && !busy && run()} />
      <button className="primary" disabled={busy || !url.trim()} onClick={run}>
        {busy ? 'Capturing the page…' : 'Use this page'}
      </button>
      {msg && <p className="note">{msg}</p>}
    </div>
  );
};

export const Inspector: React.FC<Props> = (props) => (
  <PeekContext.Provider value={props.peek ?? (() => {})}>
    <InspectorBody {...props} />
  </PeekContext.Provider>
);

const InspectorBody: React.FC<Props> = ({ project: p, update, selection, select, setDuration, onUpload, seek }) => {
  const set = (fn: (p: DemoProject) => DemoProject) => update(fn, true);

  const header = (title: string, icon: React.ReactNode, color: string, onDelete?: () => void) => (
    <>
      <button className="insp-back" title="Back to the project settings (Esc)" onClick={() => select({ type: 'project' })}>
        <Icon.back size={14} /> Project
      </button>
      <div className="insp-head">
        <span className="layer-icon" style={{ color, background: `${color}22` }}>{icon}</span>
        <h3>{title}</h3>
        {onDelete && (
          <button className="mini danger" title="Delete" onClick={onDelete}><Icon.trash size={14} /></button>
        )}
      </div>
    </>
  );

  if (selection.type === 'section') {
    const s = p.sections.find((x) => x.id === selection.id);
    if (!s) return null;
    const setS = (patch: Partial<typeof s>) => set((q) => ({ ...q, sections: q.sections.map((x) => (x.id === s.id ? { ...x, ...patch } : x)) }));
    return (
      <div className="inspector">
        {header('Section', <Icon.sections />, s.color, p.sections.length > 1 && s.start > 0 ? () => { set((q) => ({ ...q, sections: q.sections.filter((x) => x.id !== s.id) })); select({ type: 'project' }); } : undefined)}
        <Field label="Name"><input value={s.name} onChange={(e) => setS({ name: e.target.value })} /></Field>
        <Field label="Starts at" hint="s"><input type="number" step={0.1} value={s.start} onChange={(e) => setS({ start: Number(e.target.value) })} /></Field>
        <Field label="Colour"><input type="color" value={s.color} onChange={(e) => setS({ color: e.target.value })} /></Field>
        <p className="note">Sections named <b>Drop</b> trigger the beat-drop punch and flash. <b>Title</b> starts the end card.</p>
      </div>
    );
  }

  if (selection.type === 'camera') {
    const k = p.camera[selection.index];
    if (!k) return null;
    const setK = (patch: Partial<CameraKey>) => set((q) => ({ ...q, camera: q.camera.map((x, i) => (i === selection.index ? { ...x, ...patch } : x)) }));
    return (
      <div className="inspector">
        {header(`Camera key · ${k.t.toFixed(2)}s`, <Icon.camera />, '#60a5fa', p.camera.length > 2 ? () => { set((q) => ({ ...q, camera: q.camera.filter((_, i) => i !== selection.index) })); select({ type: 'project' }); } : undefined)}
        <Field label="Time" hint="s"><Slider value={k.t} min={0} max={p.duration} step={0.05} onChange={(t) => setK({ t })} /></Field>
        <Field label="Tilt (X)"><Slider value={k.rotateX} min={-10} max={85} step={1} fmt={(v) => `${v}°`} onChange={(rotateX) => setK({ rotateX })} /></Field>
        <Field label="Swing (Y)"><Slider value={k.rotateY} min={-45} max={45} step={1} fmt={(v) => `${v}°`} onChange={(rotateY) => setK({ rotateY })} /></Field>
        <Field label="Roll (Z)"><Slider value={k.rotateZ} min={-45} max={45} step={1} fmt={(v) => `${v}°`} onChange={(rotateZ) => setK({ rotateZ })} /></Field>
        <Field label="Zoom"><Slider value={k.scale} min={0.3} max={3} step={0.01} onChange={(scale) => setK({ scale })} /></Field>
        <Field label="Pan X"><Slider value={k.x} min={-800} max={800} step={5} fmt={(v) => `${v}px`} onChange={(x) => setK({ x })} /></Field>
        <Field label="Pan Y"><Slider value={k.y} min={-600} max={700} step={5} fmt={(v) => `${v}px`} onChange={(y) => setK({ y })} /></Field>
        <Field label="Focus point" hint="top → bottom"><Slider value={k.focus} min={0} max={1} onChange={(focus) => setK({ focus })} /></Field>
      </div>
    );
  }

  if (selection.type === 'zoom') {
    const z = (p.zooms ?? []).find((x) => x.id === selection.id);
    if (!z) return null;
    const setZ = (patch: Partial<typeof z>) => set((q) => ({ ...q, zooms: (q.zooms ?? []).map((x) => (x.id === z.id ? { ...x, ...patch } : x)) }));
    return (
      <div className="inspector">
        {header('Zoom-in', <Icon.zoom />, '#fdba74', () => { set((q) => ({ ...q, zooms: (q.zooms ?? []).filter((x) => x.id !== z.id) })); select({ type: 'project' }); })}
        <ZoomPicker media={p} x={z.x} y={z.y} onPick={(x, y) => setZ({ x, y })} />
        <Field label="Zoom" hint="×"><Slider value={z.scale} min={1.2} max={3} step={0.1} fmt={(v) => `${v.toFixed(1)}×`} onChange={(scale) => setZ({ scale })} /></Field>
        <Field label="Start" hint="s"><input type="number" step={0.1} value={z.start} onChange={(e) => setZ({ start: Number(e.target.value) })} /></Field>
        <Field label="Duration" hint="s"><input type="number" step={0.1} value={z.duration} onChange={(e) => setZ({ duration: Number(e.target.value) })} /></Field>
        <p className="note">Click the thumbnail to choose where the camera zooms in. The camera turns to face the screen while it is zoomed.</p>
      </div>
    );
  }

  if (selection.type === 'shot') {
    const x = (p.shots ?? []).find((o) => o.id === selection.id);
    if (!x) return null;
    return (
      <div className="inspector">
        {header('Shot', <Icon.shot />, '#c4b5fd', () => { set((q) => ({ ...q, shots: (q.shots ?? []).filter((o) => o.id !== x.id) })); select({ type: 'project' }); })}
        <ShotPanel project={p} shot={x} update={update} />
      </div>
    );
  }

  if (selection.type === 'callout') {
    const c = p.callouts.find((x) => x.id === selection.id);
    if (!c) return null;
    const setC = (patch: Partial<typeof c>) => set((q) => ({ ...q, callouts: q.callouts.map((x) => (x.id === c.id ? { ...x, ...patch } : x)) }));
    return (
      <div className="inspector">
        {header('Callout', <Icon.callout />, '#67e8f9', () => { set((q) => ({ ...q, callouts: q.callouts.filter((x) => x.id !== c.id) })); select({ type: 'project' }); })}
        <Field label="Text"><input value={c.text} onChange={(e) => setC({ text: e.target.value })} /></Field>
        <Field label="Anchor X" hint="on the screen"><Slider value={c.x} min={0} max={1} onChange={(x) => setC({ x })} /></Field>
        <Field label="Anchor Y"><Slider value={c.y} min={0} max={1} onChange={(y) => setC({ y })} /></Field>
        <Field label="Shortcut" hint="optional"><input value={c.keys ?? ''} placeholder="⌘ K" onChange={(e) => setC({ keys: e.target.value || undefined })} /></Field>
        <Field label="Style">
          <select value={c.style ?? ''} onChange={(e) => setC({ style: (e.target.value || undefined) as typeof c.style })} aria-label="Callout style">
            <option value="">Project default ({CALLOUT_STYLES.find((s) => s.key === (p.calloutStyle ?? 'glass'))?.label})</option>
            {CALLOUT_STYLES.map((s) => <option key={s.key} value={s.key}>{s.label}: {s.hint}</option>)}
          </select>
        </Field>
        <Field label="Element width" hint="circles, underlines, presses"><Slider value={c.w ?? (isPhone(p.device) ? 0.78 : 0.2)} min={0.03} max={1} onChange={(w) => setC({ w })} /></Field>
        <Field label="Element height"><Slider value={c.h ?? (isPhone(p.device) ? 0.075 : 0.07)} min={0.02} max={0.5} onChange={(h) => setC({ h })} /></Field>
        <Field label="Start" hint="s"><input type="number" step={0.1} value={c.start} onChange={(e) => setC({ start: Number(e.target.value) })} /></Field>
        <Field label="Duration" hint="s"><input type="number" step={0.1} value={c.duration} onChange={(e) => setC({ duration: Number(e.target.value) })} /></Field>
        <p className="note">Anchor is the centre of the UI element the callout points at (0 = left/top, 1 = right/bottom); the element size frames circles, underlines, highlights and button presses. A shortcut shows as keycaps while the callout is up; ⌘ becomes Ctrl on Windows and Android.</p>
      </div>
    );
  }

  if (selection.type === 'layer') {
    if (selection.layer === 'depthScan')
      return (
        <div className="inspector">
          {header('Depth Scan', <Icon.scan />, '#f9a8d4')}
          <Field label="Threshold" hint="edge sharpness"><Slider value={p.depthScan.threshold} min={0} max={1} onChange={(threshold) => set((q) => ({ ...q, depthScan: { ...q.depthScan, threshold } }))} /></Field>
          <Field label="Depth of field" hint="blur px"><Slider value={p.dof} min={0} max={20} step={0.5} fmt={(v) => `${v}px`} onChange={(dof) => set((q) => ({ ...q, dof }))} /></Field>
          <p className="note">A lit edge sweeps across the screen and reveals it in full colour; the rest stays out of focus.</p>
        </div>
      );
    if (selection.layer === 'focusType')
      return (
        <div className="inspector">
          {header('Focus Type', <Icon.type />, '#fcd34d')}
          <Field label="Intro text"><input value={p.focusType.text} onChange={(e) => set((q) => ({ ...q, focusType: { ...q.focusType, text: e.target.value } }))} /></Field>
          <TextStylePicker project={p} set={set} />
          <p className="note">The same animation brings in the title on the end card.</p>
        </div>
      );
    if (selection.layer === 'gradient')
      return (
        <div className="inspector">
          {header('Background', <Icon.gradient />, '#f0abfc')}
          <PaletteField project={p} update={update} />
          <BackdropField project={p} update={update} />
          <Field label="Glow"><Slider value={p.glow} min={0} max={1.5} onChange={(glow) => set((q) => ({ ...q, glow }))} /></Field>
        </div>
      );
    return (
      <div className="inspector">
        {header('Score', <Icon.music />, '#86efac')}
        <MusicPicker project={p} update={update} />
        <Field label="Track name"><input value={p.score.name} onChange={(e) => set((q) => ({ ...q, score: { ...q.score, name: e.target.value } }))} /></Field>
        <Field label="Volume"><Slider value={p.score.volume} min={0} max={1} onChange={(volume) => set((q) => ({ ...q, score: { ...q.score, volume } }))} /></Field>
        <BeatSync project={p} update={update} />
        <p className="note">Upload your own music with the upload button, or pick a built-in track: they are made for Lumora and free to use in any video.</p>
      </div>
    );
  }

  return <ProjectPanel project={p} update={update} select={select} setDuration={setDuration} onUpload={onUpload} seek={seek} />;
};

const download = (name: string, text: string) => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' }));
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
};

// Zoom-ins where things happen in the recording, found from the picture (no cursor data needed)
const AutoZoom: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project: p, update }) => {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const run = async () => {
    setBusy(true);
    setMsg(null);
    try {
      const { events } = await api.post<{ events: MotionEvent[] }>('/api/media/motion', { src: p.media.src });
      const zooms = zoomsFromMotion(p, events);
      if (!zooms.length) return setMsg('Nothing focused happens on screen to zoom into.');
      update((q) => ({ ...q, zooms, effects: { ...q.effects, motionBlur: true } }), true);
      setMsg(`${zooms.length} zoom${zooms.length > 1 ? 's' : ''} where things happen. They replace the old ones.`);
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Field label="Auto zoom" hint={p.zooms?.length ? `${p.zooms.length} zooms` : undefined}>
      <div className="auto">
        <div className="chips">
          <button className="chip" disabled={busy} title="Finds typing, clicks and moving parts in the recording and zooms in on them" onClick={run}>{busy ? 'Watching…' : 'Zoom where things happen'}</button>
          {!!p.zooms?.length && <button className="chip" onClick={() => update((q) => ({ ...q, zooms: [] }), true)}>Clear zooms</button>}
        </div>
        {msg && <p className="note">{msg}</p>}
      </div>
    </Field>
  );
};

// The presenter's webcam, recorded next to the screen, in a corner bubble
// What sits behind the screen: the dark stage, a gradient wallpaper in the palette, a
// built-in wallpaper image or the user's own picture.
const BackdropField: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project: p, update }) => {
  const file = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const pick = (backdrop: string | undefined, wallpaper: boolean) =>
    update((q) => ({ ...q, backdrop, effects: { ...q.effects, wallpaper: wallpaper || undefined } }), true);
  const add = async (f: File) => {
    setBusy(true);
    setMsg(null);
    try {
      const up = await uploadFile(f);
      if (up.kind !== 'image') throw new Error('Choose a picture, e.g. .jpg, .png or .webp');
      pick(up.url, false);
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const own = p.backdrop && !WALLPAPERS.some((w) => w.src === p.backdrop);
  const cols = paletteOf(p);
  const peek = usePeek();
  const look = (backdrop: string | undefined, wallpaper: boolean, label: string) => peek(label, (q) => ({ ...q, backdrop, effects: { ...q.effects, wallpaper: wallpaper || undefined } }));
  return (
    <Field label="Behind the screen">
      <div className="backdrops">
        <button className={`backdrop ${!p.backdrop && !p.effects?.wallpaper ? 'on' : ''}`} title="Dark stage with glow, grid and bokeh" onClick={() => pick(undefined, false)} {...look(undefined, false, 'Stage')}>
          <span style={{ background: `radial-gradient(circle at 40% 35%, ${cols[0]}88, transparent 60%), #030409` }} />
          Stage
        </button>
        <button className={`backdrop ${!p.backdrop && p.effects?.wallpaper ? 'on' : ''}`} title="A bright gradient in the palette's colours" onClick={() => pick(undefined, true)} {...look(undefined, true, 'Gradient')}>
          <span style={{ background: `linear-gradient(135deg, ${cols[0]}, ${cols[2]})` }} />
          Gradient
        </button>
        {WALLPAPERS.map((w) => (
          <button key={w.src} className={`backdrop ${p.backdrop === w.src ? 'on' : ''}`} onClick={() => pick(w.src, false)} {...look(w.src, false, w.name)}>
            <span style={{ backgroundImage: `url(${resolveSrc(w.thumb)})` }} />
            {w.name}
          </button>
        ))}
        <button className={`backdrop ${own ? 'on' : ''}`} disabled={busy} title="Use your own picture" onClick={() => file.current?.click()}>
          <span style={own ? { backgroundImage: `url(${resolveSrc(p.backdrop!)})` } : { display: 'grid', placeItems: 'center' }}>{!own && <Icon.upload size={14} />}</span>
          {busy ? 'Uploading…' : 'Your image'}
        </button>
      </div>
      <input ref={file} type="file" accept="image/*" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) add(f); }} />
      {msg && <p className="note err">{msg}</p>}
    </Field>
  );
};

const WebcamField: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project: p, update }) => {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const file = useRef<HTMLInputElement>(null);
  const cam = p.cam;
  const put = (c: Partial<NonNullable<DemoProject['cam']>>) => update((q) => (q.cam ? { ...q, cam: { ...q.cam, ...c } } : q), true);
  const add = async (f: File) => {
    setBusy(true);
    setMsg(null);
    try {
      const up = await uploadFile(f);
      if (up.kind !== 'video') throw new Error('Choose the webcam video, e.g. .mp4, .mov or .webm');
      update((q) => ({ ...q, cam: { corner: 'bl', size: 0.26, shape: 'circle', ...q.cam, src: up.url } }), true);
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <div className="stack">
        <div className="chips">
          <button className="chip" disabled={busy} title="A webcam video recorded at the same time as the screen" onClick={() => file.current?.click()}>{busy ? 'Uploading…' : cam ? 'Replace webcam' : 'Add webcam video'}</button>
          {cam && <button className="chip" onClick={() => update((q) => ({ ...q, cam: undefined }), true)}>Remove</button>}
        </div>
        <input ref={file} type="file" accept="video/*" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) add(f); }} />
        {cam && (
          <>
            <div className="chips">
              {CAM_CORNERS.map((c) => (
                <button key={c.key} className={`chip ${(cam.corner ?? 'bl') === c.key ? 'on' : ''}`} title="Corner" onClick={() => put({ corner: c.key })}>{c.label}</button>
              ))}
              <button className={`chip ${cam.shape !== 'rounded' ? 'on' : ''}`} onClick={() => put({ shape: 'circle' })}>Circle</button>
              <button className={`chip ${cam.shape === 'rounded' ? 'on' : ''}`} onClick={() => put({ shape: 'rounded' })}>Rounded</button>
            </div>
            <Slider value={cam.size ?? 0.26} min={0.15} max={0.4} step={0.01} fmt={(v) => `${Math.round(v * 100)}%`} onChange={(size) => put({ size })} />
            <div className="chips">
              <button className={`chip ${cam.sound ? 'on' : ''}`} title="Hear the webcam's microphone" onClick={() => put({ sound: cam.sound ? undefined : 1 })}>Webcam mic</button>
              {p.media.kind === 'video' && <span className="note">Starts {(cam.offset ?? 0) >= 0 ? '+' : ''}{(cam.offset ?? 0).toFixed(1)} s</span>}
              {p.media.kind === 'video' && <button className="chip" title="Webcam is behind: start it earlier" onClick={() => put({ offset: Math.round(((cam.offset ?? 0) - 0.1) * 10) / 10 })}>−0.1</button>}
              {p.media.kind === 'video' && <button className="chip" title="Webcam is ahead: start it later" onClick={() => put({ offset: Math.round(((cam.offset ?? 0) + 0.1) * 10) / 10 })}>+0.1</button>}
            </div>
          </>
        )}
        {msg && <p className="note">{msg}</p>}
        {!cam && <p className="note">A webcam video recorded with the screen plays in a corner bubble.</p>}
      </div>
    </>
  );
};

// Edit the recording by its words: pick words and cut them, or clear out the ums and uhs.
// A cut leaves that stretch of the recording out of the video, screen and sound together.
const Transcript: React.FC<{ project: DemoProject; update: Props['update']; setDuration: (d: number) => void; seek?: (t: number) => void }> = ({ project: p, update, setDuration, seek }) => {
  const [sel, setSel] = useState<[number, number] | null>(null);
  const words = p.media.words ?? [];
  const length = p.media.length ?? words[words.length - 1].endMs / 1000 + 1;
  const isCut = (i: number) => toTimeline(p.media, (words[i].startMs + words[i].endMs) / 2000) === null;
  const fillers = words.map((w, i) => (isFiller(w.text) && !isCut(i) ? i : -1)).filter((i) => i >= 0);
  const apply = (segments: Segment[]) => {
    update((q) => ({ ...q, media: { ...q.media, segments: segments.length ? segments : undefined } }), true);
    setDuration(Math.max(5, Math.min(60, Math.round(keptSeconds({ ...p.media, segments })))));
    setSel(null);
  };
  const pick = (i: number, extend: boolean) => {
    const next: [number, number] = extend && sel ? [Math.min(sel[0], i), Math.max(sel[1], i)] : [i, i];
    setSel(next);
    const t = toTimeline(p.media, words[i].startMs / 1000);
    if (t !== null) seek?.(t);
  };
  const selCut = sel ? Array.from({ length: sel[1] - sel[0] + 1 }, (_, k) => isCut(sel[0] + k)).every(Boolean) : false;
  return (
    <div className="transcript-box">
      <div className="transcript" aria-label="Transcript">
        {words.map((w, i) => (
          <span
            key={i}
            className={`tw ${isCut(i) ? 'cut' : ''} ${sel && i >= sel[0] && i <= sel[1] ? 'sel' : ''} ${isFiller(w.text) ? 'filler' : ''}`}
            onClick={(e) => pick(i, e.shiftKey)}
          >
            {w.text}{' '}
          </span>
        ))}
      </div>
      <div className="chips">
        {sel && !selCut && (
          <button className="chip" title="Leave these words out of the video" onClick={() => apply(cutRanges(p.media, [wordsRange(words, sel[0], sel[1])], length))}>
            Cut {sel[1] - sel[0] + 1} word{sel[1] > sel[0] ? 's' : ''}
          </button>
        )}
        {sel && selCut && (
          <button className="chip" title="Put these words back" onClick={() => apply(restoreRanges(p.media, [wordsRange(words, sel[0], sel[1])], length))}>Restore</button>
        )}
        {fillers.length > 0 && (
          <button className="chip" title="Cut every um, uh and öö" onClick={() => apply(cutRanges(p.media, fillers.map((i) => wordsRange(words, i, i)), length))}>
            Remove {fillers.length} filler word{fillers.length > 1 ? 's' : ''}
          </button>
        )}
      </div>
      <small className="muted">Click a word to jump there, shift-click to pick a run, then cut it. The screen is cut with it.</small>
    </div>
  );
};

// Gentle notes on wording that makes a video look like a template (cinetic's copy rules)
// The final check: hold times, slams, star moves, text off the frame. Click a note to go there.
const FilmCheck: React.FC<{ project: DemoProject; select: (s: Selection) => void; seek?: (t: number) => void }> = ({ project: p, select, seek }) => {
  const notes = filmCheck(p);
  if (!notes.length) return null;
  const fixes = notes.filter((n) => n.level === 'fix').length;
  return (
    <Group label={fixes ? `${fixes} to fix before export` : `${notes.length} tip${notes.length > 1 ? 's' : ''}`}>
      <ul className="copy-notes film-notes">
        {notes.slice(0, 6).map((n, i) => (
          <li key={i} className={n.level}>
            <button className="link" onClick={() => { if (n.at !== undefined) seek?.(n.at); if (n.shot) select({ type: 'shot', id: n.shot }); }}><b>{n.where}</b></button> {n.tip}
          </li>
        ))}
      </ul>
    </Group>
  );
};

const CopyCheck: React.FC<{ project: DemoProject }> = ({ project: p }) => {
  const notes = copyNotes(p);
  if (!notes.length) return null;
  return (
    <Field label="Copy check" hint={`${notes.length} note${notes.length > 1 ? 's' : ''}`}>
      <ul className="copy-notes">
        {notes.slice(0, 4).map((n, i) => (
          <li key={i}><b>{n.where}</b> {n.tip}</li>
        ))}
      </ul>
    </Field>
  );
};

// Speech that is already there: the recording's own sound, or a voiceover the user recorded.
// Either is transcribed on the server and captioned word by word.
const SpeechField: React.FC<{ project: DemoProject; update: Props['update']; setDuration: (d: number) => void; speech: boolean; seek?: (t: number) => void }> = ({ project: p, update, setDuration, speech, seek }) => {
  const { requireAuth } = useAccount();
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const file = useRef<HTMLInputElement>(null);
  const video = p.media.kind === 'video';
  const ownVoice = !!p.narration?.src && !p.narration.voice;
  const run = async (label: string, fn: () => Promise<void>) => {
    if (!(await requireAuth('Create a free account to caption speech.'))) return;
    setBusy(label);
    setMsg(null);
    try {
      await fn();
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setBusy(null);
    }
  };
  const transcribe = (src: string) => api.post<{ words: { text: string; startMs: number; endMs: number }[]; text: string; language?: string }>('/api/media/transcribe', { src, hint: [p.title, p.tagline, ...p.callouts.map((c) => c.text)].filter(Boolean).join('. ') });
  const fromRecording = () =>
    run('rec', async () => {
      // the webcam's mic when that is what is heard; its words move onto the recording's clock
      const cam = p.cam?.sound ? p.cam : undefined;
      const t = await transcribe(cam ? cam.src : p.media.src);
      if (!t.words.length) throw new Error('No speech found in the recording.');
      const shift = Math.round((cam?.offset ?? 0) * 1000);
      const words = t.words.map((w) => ({ ...w, startMs: w.startMs + shift, endMs: w.endMs + shift }));
      update((q) => ({ ...q, media: { ...q.media, words, sound: cam ? q.media.sound : q.media.sound ?? 1 }, captions: q.captions ?? 'clean' }), true);
      setMsg(`Captioned ${t.words.length} words${t.language ? ` (${t.language})` : ''}.`);
    });
  // the voice that is heard: the recording's sound, the webcam mic, or an uploaded voiceover
  const heard = (video && !!p.media.sound) || !!p.cam?.sound || ownVoice;
  const cleaned = !!p.media.soundSrc || !!p.cam?.soundSrc;
  const clean = () =>
    run('clean', async () => {
      const fix = (src: string) => api.post<{ url: string }>('/api/media/clean-audio', { src }).then((r) => r.url);
      const media = video && p.media.sound ? await fix(p.media.src) : undefined;
      const cam = p.cam?.sound ? await fix(p.cam.src) : undefined;
      const voice = ownVoice ? await fix(p.narration!.src!) : undefined;
      update((q) => ({
        ...q,
        media: media ? { ...q.media, soundSrc: media } : q.media,
        cam: cam && q.cam ? { ...q.cam, soundSrc: cam } : q.cam,
        narration: voice && q.narration ? { ...q.narration, src: voice } : q.narration,
      }), true);
      setMsg('Voice cleaned: less background noise, even level.');
    });
  const tighten = () => {
    const words = p.media.words ?? [];
    const parts = tightenPauses(words, p.media.length ?? words[words.length - 1].endMs / 1000 + 1);
    if (!parts.some((g) => g.speed > 1)) return setMsg('No long pauses to tighten.');
    update((q) => ({ ...q, media: { ...q.media, segments: parts } }), true);
    setDuration(Math.max(5, Math.min(60, Math.round(keptSeconds({ ...p.media, segments: parts })))));
    setMsg(`Sped up ${parts.filter((g) => g.speed > 1).length} pauses 3×.`);
  };
  const fromUpload = (f: File) =>
    run('voice', async () => {
      const up = await uploadFile(f);
      if (up.kind !== 'audio' && up.kind !== 'video') throw new Error('Choose an audio file, e.g. .m4a, .mp3 or .wav');
      let words: { text: string; startMs: number; endMs: number }[] | undefined;
      let script = p.narration?.script ?? '';
      if (speech) {
        const t = await transcribe(up.url);
        words = t.words.length ? t.words : undefined;
        script = t.text || script;
      }
      const start = narrationStart(p);
      update((q) => ({ ...q, narration: { script, src: up.url, words, start, volume: q.narration?.volume ?? 1 }, captions: words ? q.captions ?? 'clean' : q.captions }), true);
      if (up.duration && start + up.duration > p.duration - 2) setDuration(Math.min(60, Math.ceil(start + up.duration + 2.5)));
      setMsg(words ? `Your voice is in, with ${words.length} captioned words.` : 'Your voice is in. Captions follow the script.');
    });
  return (
    <Field label="Speech" hint={speech ? 'auto captions' : undefined}>
      <div className="auto">
        {video && (
          <div className="chips">
            <button className={`chip ${p.media.sound === undefined ? 'on' : ''}`} onClick={() => update((q) => ({ ...q, media: { ...q.media, sound: undefined } }), true)}>Muted</button>
            <button className={`chip ${p.media.sound !== undefined ? 'on' : ''}`} title="Play the sound recorded with the screen" onClick={() => update((q) => ({ ...q, media: { ...q.media, sound: q.media.sound ?? 1 } }), true)}>Recording sound</button>
          </div>
        )}
        {video && p.media.sound !== undefined && <Slider value={p.media.sound} min={0} max={1.5} onChange={(sound) => update((q) => ({ ...q, media: { ...q.media, sound } }), true)} />}
        <div className="chips">
          {video && speech && (
            <button className="chip" disabled={!!busy} title="Turn what you say in the recording into captions" onClick={fromRecording}>
              {busy === 'rec' ? 'Listening…' : p.media.words?.length ? 'Re-caption speech' : 'Captions from speech'}
            </button>
          )}
          <button className="chip" disabled={!!busy} title="Use your own recorded voiceover instead of an AI voice" onClick={() => file.current?.click()}>
            {busy === 'voice' ? (speech ? 'Uploading and listening…' : 'Uploading…') : ownVoice ? 'Replace my voice' : 'Upload my voice'}
          </button>
          {video && !!p.media.words?.length && (
            <button className="chip" title="Pauses between your words play 3× faster; what happens on screen stays" onClick={tighten}>Tighten pauses</button>
          )}
          {heard && (
            cleaned ? (
              <button className="chip on" title="Back to the original sound" onClick={() => update((q) => ({ ...q, media: { ...q.media, soundSrc: undefined }, cam: q.cam ? { ...q.cam, soundSrc: undefined } : q.cam }), true)}>Voice cleaned</button>
            ) : (
              <button className="chip" disabled={!!busy} title="Less background noise and an even, streaming-ready level" onClick={clean}>{busy === 'clean' ? 'Cleaning…' : 'Clean up voice'}</button>
            )
          )}
          {video && !!p.media.words?.length && (
            <button className="chip" title="Captions go back to the script" onClick={() => update((q) => ({ ...q, media: { ...q.media, words: undefined } }), true)}>Drop speech captions</button>
          )}
        </div>
        {video && !!p.media.words?.length && <Transcript project={p} update={update} setDuration={setDuration} seek={seek} />}
        <input ref={file} type="file" accept="audio/*,.m4a,.mp3,.wav" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) fromUpload(f); }} />
        {msg && <p className="note">{msg}</p>}
        {!speech && <p className="note">Captions from speech turn on when the server has whisper.cpp or an OpenAI key.</p>}
      </div>
    </Field>
  );
};

// Voiceover script, AI voice, burned-in captions and the end-card call to action.
const VoicePanel: React.FC<{ project: DemoProject; update: Props['update']; setDuration: (d: number) => void; seek?: (t: number) => void }> = ({ project: p, update, setDuration, seek }) => {
  const { locked, unlock } = useProGate();
  const [voices, setVoices] = useState<{ provider: string | null; voices: { id: string; name: string }[]; speech?: string | null } | null>(null);
  const [voice, setVoice] = useState(p.narration?.voice ?? '');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => {
    fetch('/api/voices').then((r) => r.json()).then(setVoices, () => setVoices({ provider: null, voices: [] }));
  }, []);
  const n = p.narration ?? { script: '' };
  const setScript = (script: string) =>
    update((q) => {
      const own = q.narration?.src && !q.narration.voice;
      // an AI voice no longer matches edited words, so it is dropped; the user's own recording
      // stays, and fixing a misheard word keeps its timing
      if (!own) return { ...q, narration: { ...q.narration, script, src: undefined, words: undefined } };
      const tokens = script.split(/\s+/).filter(Boolean);
      const words = q.narration?.words;
      return { ...q, narration: { ...q.narration!, script, words: words && tokens.length === words.length ? words.map((w, i) => ({ ...w, text: tokens[i] })) : undefined } };
    }, false);
  const generate = async () => {
    if (!(await unlock('AI voice', 'Pick a voice and it reads your script over the video, with captions to match.'))) return;
    setBusy(true);
    setMsg(null);
    try {
      const r = await fetch('/api/voiceover', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ script: n.script, voice: voice || undefined }) });
      const body = await r.json();
      if (!r.ok) throw new Error(body.error ?? 'Voiceover failed');
      const start = narrationStart(p);
      update((q) => ({ ...q, narration: { ...q.narration, script: n.script, src: body.src, words: body.words, voice: body.voice, start, volume: q.narration?.volume ?? 1 } }), true);
      if (start + body.seconds > p.duration - 2) setMsg(`The voice runs ${body.seconds.toFixed(1)} s. Make the video ${Math.ceil(start + body.seconds + 3)} s long so it ends before the title.`);
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const fit = msg?.match(/Make the video (\d+) s/);
  return (
    <>
      <Field label="Voiceover" hint={voices?.provider ? (locked ? 'AI voice · Pro' : 'AI voice') : 'script'}>
        <div className="auto voice">
          <textarea
            rows={3}
            value={n.script}
            placeholder="What a narrator says over the video. AI direction writes this for you."
            onChange={(e) => setScript(e.target.value)}
            onBlur={() => update((q) => q, true)}
          />
          {voices?.provider ? (
            <div className="voice-row">
              <select value={voice} onChange={(e) => setVoice(e.target.value)} aria-label="Voice">
                <option value="">{voices.voices[0]?.name ?? 'Default voice'}</option>
                {voices.voices.slice(1).map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
              </select>
              <button className="secondary" disabled={busy || (!locked && !n.script.trim())} title={locked ? 'Pro and Team feature' : undefined} onClick={generate}>
                {locked && <Icon.lock size={13} />}
                {busy ? 'Recording…' : n.src ? 'Re-record' : 'Generate voice'}
              </button>
            </div>
          ) : (
            !n.src && <p className="note">Captions use this script now. AI voice turns on when the server has an ElevenLabs or OpenAI key.</p>
          )}
          {n.src && (
            <div className="voice-row">
              <audio src={resolveSrc(n.src)} controls />
              <button className="mini danger" title="Remove voice" onClick={() => update((q) => ({ ...q, narration: { ...q.narration!, src: undefined, words: undefined } }), true)}><Icon.trash size={14} /></button>
            </div>
          )}
          {msg && (
            <p className="note">
              {msg} {fit && <button className="link" onClick={() => { setDuration(Number(fit[1])); setMsg(null); }}>Make it {fit[1]} s</button>}
            </p>
          )}
        </div>
      </Field>
      {n.src && (
        <Field label="Voice volume"><Slider value={n.volume ?? 1} min={0} max={1.5} onChange={(volume) => update((q) => ({ ...q, narration: { ...q.narration!, volume } }), true)} /></Field>
      )}
      <SpeechField project={p} update={update} setDuration={setDuration} speech={!!voices?.speech} seek={seek} />
    </>
  );
};

// Find the tempo and the drop in the music, then land the edit on the beat.
// The built-in tracks: ▶ previews one without touching the project, picking one puts it on the
// score and lands the edit on its beat, like an uploaded track.
const MusicPicker: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project: p, update }) => {
  const [playing, setPlaying] = useState<string | null>(null);
  const audio = useRef<HTMLAudioElement | null>(null);
  useEffect(() => () => audio.current?.pause(), []);
  const preview = (t: Track) => {
    if (!audio.current) {
      audio.current = new Audio();
      audio.current.onended = () => setPlaying(null);
    }
    const a = audio.current;
    if (playing === t.src) {
      a.pause();
      return setPlaying(null);
    }
    a.src = resolveSrc(t.src);
    a.volume = 0.8;
    void a.play().catch(() => setPlaying(null));
    setPlaying(t.src);
  };
  const pick = (t: Track) => update((q) => snapToBeat(withTrack(q, t), beatInfo(t)), true);
  const list = TRACKS.filter((t) => !t.classic || t.src === p.score.src);
  return (
    <Field label="Built-in tracks" hint={`${list.length}`}>
      <div className="music-list">
        {list.map((t) => (
          <div key={t.src} className={`music-row ${p.score.src === t.src ? 'on' : ''}`}>
            <button className="track-play" aria-label={playing === t.src ? `Stop ${t.name}` : `Preview ${t.name}`} onClick={() => preview(t)}>
              {playing === t.src ? <Icon.pause size={12} /> : <Icon.play size={12} />}
            </button>
            <button className="track-pick" title={`Use ${t.name}`} onClick={() => pick(t)}>
              <b>{t.name}</b>
              <small>{t.mood}</small>
            </button>
            <span className="track-bpm">{t.bpm}</span>
          </div>
        ))}
      </div>
    </Field>
  );
};

const BeatSync: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project: p, update }) => {
  const [state, setState] = useState<'idle' | 'busy' | 'failed'>('idle');
  const sync = async () => {
    setState('busy');
    const info = p.score.src ? await analyzeBeats(resolveSrc(p.score.src)) : null;
    if (!info) return setState('failed');
    update((q) => snapToBeat(q, info), true);
    setState('idle');
  };
  return (
    <Field label="Beat sync" hint={p.score.bpm ? `${p.score.bpm} BPM` : undefined}>
      <button className="secondary beat-btn" disabled={state === 'busy' || !p.score.src} onClick={sync}>
        <Icon.music size={14} /> {state === 'busy' ? 'Listening…' : 'Snap the edit to the beat'}
      </button>
      <p className="note">{state === 'failed' ? 'Could not read the beat of this track.' : 'Moves the drop onto the music\'s drop and lands cuts, callouts and zooms on beats.'}</p>
    </Field>
  );
};

// Editing one shot: its kind from the library, its words, numbers, screens, look and cuts.
const TEXT_LABEL: Partial<Record<Shot['kind'], string>> = { headline: 'Text', cycle: 'Words before', mask: 'Word', screen: 'Caption', deck: 'Caption', wall: 'Caption', carousel: 'Caption', chart: 'Title', logo: 'Name', cta: 'Button' };
const SUB_LABEL: Partial<Record<Shot['kind'], string>> = { headline: 'Small line', logo: 'Line under', cta: 'Link' };
const WORDS_LABEL: Partial<Record<Shot['kind'], string>> = { cycle: 'Words that swap', flashes: 'A word per cut', compare: 'Labels' };
const USES_SCREENS: Shot['kind'][] = ['screen', 'deck', 'wall', 'carousel', 'compare', 'mask', 'flashes'];

const ShotPanel: React.FC<{ project: DemoProject; shot: Shot; update: Props['update'] }> = ({ project: p, shot: x, update }) => {
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const put = (patch: Partial<Shot>, commit = true) => update((q) => ({ ...q, shots: (q.shots ?? []).map((o) => (o.id === x.id ? { ...o, ...patch } : o)) }), commit);
  const meta = SHOT_KINDS.find((k) => k.key === x.kind)!;
  // a new kind starts from its own defaults; the place, length and chosen screens stay
  const setKind = (kind: Shot['kind']) => {
    const fresh: Shot = { ...newShot(p, kind, x.start), id: x.id, duration: x.duration, ...(x.images ? { images: x.images } : {}) };
    update((q) => ({ ...q, shots: (q.shots ?? []).map((o) => (o.id === x.id ? fresh : o)) }), true);
  };
  const addImages = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    try {
      const urls: string[] = [];
      for (const f of Array.from(files).slice(0, 8)) urls.push((await uploadFile(f)).url);
      put({ images: [...(x.images ?? []), ...urls].slice(0, 8) });
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const groups = [...new Set(SHOT_KINDS.map((k) => k.group))];
  return (
    <>
      <Group label="Shot" hint="from the library">
        <div className="shot-lib">
          {groups.map((g) => (
            <div key={g} className="shot-group">
              <small>{g}</small>
              <div className="chips">
                {SHOT_KINDS.filter((k) => k.group === g).map((k) => (
                  <button key={k.key} className={`chip ${x.kind === k.key ? 'on' : ''}`} title={k.hint} onClick={() => setKind(k.key)}>{k.label}</button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Group>
      <p className="note">{meta.hint}.</p>
      {meta.styles && (
        <Field label="Style">
          <div className="chips">
            {meta.styles.map((st) => (
              <button key={st.key} className={`chip ${(x.style ?? meta.styles![0].key) === st.key ? 'on' : ''}`} onClick={() => put({ style: st.key })}>{st.label}</button>
            ))}
          </div>
        </Field>
      )}
      {TEXT_LABEL[x.kind] && <Field label={TEXT_LABEL[x.kind]!}><input value={x.text ?? ''} onChange={(e) => put({ text: e.target.value }, false)} onBlur={() => put({}, true)} /></Field>}
      {SUB_LABEL[x.kind] && <Field label={SUB_LABEL[x.kind]!} hint="optional"><input value={x.sub ?? ''} onChange={(e) => put({ sub: e.target.value || undefined }, false)} onBlur={() => put({}, true)} /></Field>}
      {(WORDS_LABEL[x.kind] || (x.kind === 'headline' && x.style === 'relay')) && (
        <Field label={WORDS_LABEL[x.kind] ?? 'Words, one at a time'} hint="comma separated">
          <input value={(x.words ?? []).join(', ')} placeholder={x.kind === 'headline' ? 'the words of the text' : ''} onChange={(e) => put({ words: e.target.value.split(',').map((w) => w.trim()).filter(Boolean).slice(0, 6) }, false)} onBlur={() => put({}, true)} />
        </Field>
      )}
      {x.kind === 'stat' && (
        <Field label="Numbers" hint="up to 3">
          {(x.stats ?? []).map((st, i) => {
            const setSt = (patch: Partial<typeof st>) => put({ stats: (x.stats ?? []).map((o, j) => (j === i ? { ...o, ...patch } : o)) }, false);
            return (
              <div key={i} className="shot-row">
                <input aria-label="Before" placeholder="$" value={st.prefix ?? ''} onChange={(e) => setSt({ prefix: e.target.value || undefined })} onBlur={() => put({}, true)} />
                <input aria-label="Number" type="number" value={st.value} onChange={(e) => { const v = e.target.value; setSt({ value: Number(v), decimals: v.includes('.') ? Math.min(3, v.split('.')[1].length) : 0 }); }} onBlur={() => put({}, true)} />
                <input aria-label="After" placeholder="%" value={st.suffix ?? ''} onChange={(e) => setSt({ suffix: e.target.value || undefined })} onBlur={() => put({}, true)} />
                <input aria-label="Label" placeholder="label" value={st.label} onChange={(e) => setSt({ label: e.target.value })} onBlur={() => put({}, true)} />
                <button className="mini danger" title="Remove" onClick={() => put({ stats: (x.stats ?? []).filter((_, j) => j !== i) })}><Icon.trash size={13} /></button>
              </div>
            );
          })}
          {(x.stats ?? []).length < 3 && <button className="ghost" onClick={() => put({ stats: [...(x.stats ?? []), { value: 100, label: 'label' }] })}>Add a number</button>}
        </Field>
      )}
      {x.kind === 'chart' && (
        <Field label="Bars" hint="the last one is highlighted">
          {(x.bars ?? []).map((b, i) => {
            const setB = (patch: Partial<typeof b>) => put({ bars: (x.bars ?? []).map((o, j) => (j === i ? { ...o, ...patch } : o)) }, false);
            return (
              <div key={i} className="shot-row">
                <input aria-label="Bar label" value={b.label} onChange={(e) => setB({ label: e.target.value })} onBlur={() => put({}, true)} />
                <input aria-label="Bar value" type="number" value={b.value} onChange={(e) => setB({ value: Number(e.target.value) })} onBlur={() => put({}, true)} />
                <button className="mini danger" title="Remove" onClick={() => put({ bars: (x.bars ?? []).filter((_, j) => j !== i) })}><Icon.trash size={13} /></button>
              </div>
            );
          })}
          {(x.bars ?? []).length < 7 && <button className="ghost" onClick={() => put({ bars: [...(x.bars ?? []), { label: 'New', value: 50 }] })}>Add a bar</button>}
        </Field>
      )}
      {USES_SCREENS.includes(x.kind) && (
        <Field label="Screens" hint={x.images?.length ? `${x.images.length} of 8` : 'your recording or screenshot'}>
          <div className="shot-thumbs">
            {(x.images ?? []).map((src, i) => (
              <button key={i} className="shot-thumb" title="Remove" onClick={() => put({ images: x.images!.filter((_, j) => j !== i).length ? x.images!.filter((_, j) => j !== i) : undefined })}>
                <img src={resolveSrc(src)} alt="" />
              </button>
            ))}
            <button className="ghost" disabled={busy} onClick={() => input.current?.click()}>{busy ? 'Uploading…' : 'Add screenshots'}</button>
            <input ref={input} type="file" accept="image/png,image/jpeg,image/webp" multiple hidden onChange={(e) => addImages(e.target.files)} />
          </div>
        </Field>
      )}
      {x.kind === 'screen' && (
        <Field label="Push towards" hint="click the screen">
          <ZoomPicker media={p} x={x.focus?.x ?? 0.5} y={x.focus?.y ?? 0.4} onPick={(fx, fy) => put({ focus: { x: fx, y: fy } })} />
        </Field>
      )}
      <Field label="Backdrop">
        <div className="seg">
          {(['dark', 'light', 'brand'] as const).map((tone) => (
            <button key={tone} className={(x.tone ?? (x.style === 'paper' ? 'light' : 'dark')) === tone ? 'on' : ''} onClick={() => put({ tone })}>{tone === 'dark' ? 'Dark' : tone === 'light' ? 'Paper' : 'Brand'}</button>
          ))}
        </div>
      </Field>
      <Field label="Font">
        <div className="seg">
          {(['sans', 'serif', 'mono'] as const).map((font) => (
            <button key={font} className={(x.font ?? (x.style === 'paper' ? 'serif' : 'sans')) === font ? 'on' : ''} onClick={() => put({ font })}>{font === 'sans' ? 'Sans' : font === 'serif' ? 'Serif' : 'Mono'}</button>
          ))}
        </div>
      </Field>
      <Field label="Comes in">
        <select aria-label="Comes in" value={x.in ?? 'fade'} onChange={(e) => put({ in: e.target.value as Shot['in'] })}>
          {SHOT_TRANSITIONS.map((tr) => <option key={tr.key} value={tr.key}>{tr.label}: {tr.hint}</option>)}
        </select>
      </Field>
      <Field label="Goes out">
        <select aria-label="Goes out" value={x.out ?? 'fade'} onChange={(e) => put({ out: e.target.value as Shot['out'] })}>
          {SHOT_TRANSITIONS.map((tr) => <option key={tr.key} value={tr.key}>{tr.label}: {tr.hint}</option>)}
        </select>
      </Field>
      <Field label="Start" hint="s"><input type="number" step={0.1} value={x.start} onChange={(e) => put({ start: Math.max(0, Number(e.target.value)) })} /></Field>
      <Field label="Duration" hint="s"><input type="number" step={0.1} value={x.duration} onChange={(e) => put({ duration: Math.max(0.8, Number(e.target.value)) })} /></Field>
      <p className="note">A shot covers the whole frame for its length and cuts back to your demo when it ends. Shots that touch cut straight into each other. Beat sync lands their cuts on the beat.</p>
    </>
  );
};

// The shot library on the project panel: add a shot after the last one, or build a launch film.
const ShotsField: React.FC<{ project: DemoProject; update: Props['update']; select: (s: Selection) => void }> = ({ project: p, update, select }) => {
  const shots = [...(p.shots ?? [])].sort((a, b) => a.start - b.start);
  const add = (kind: Shot['kind']) => {
    const last = shots[shots.length - 1];
    const at = last ? Math.min(last.start + last.duration, p.duration - 1) : Math.min(2, p.duration - 1);
    const shot = newShot(p, kind, Math.max(0, at));
    update((q) => ({ ...q, shots: [...(q.shots ?? []), shot] }), true);
    select({ type: 'shot', id: shot.id });
  };
  const film = shots.some((s) => s.id.startsWith('film-'));
  return (
    <>
      {shots.length > 0 && (
        <Group label="In this video" hint="click to edit">
          <div className="chips">
            {shots.map((s, i) => (
              <button key={s.id} className="chip on" onClick={() => select({ type: 'shot', id: s.id })}>{i + 1}. {SHOT_KINDS.find((k) => k.key === s.kind)?.label}</button>
            ))}
          </div>
        </Group>
      )}
      <Group label="Add a shot" hint="cuts in over the demo">
        <div className="opt-grid">
          {SHOT_KINDS.map((k) => (
            <button key={k.key} className="chip" title={k.hint} onClick={() => add(k.key)}>{k.label}</button>
          ))}
        </div>
      </Group>
      <button className="ghost wide" disabled={film || p.duration > 50} title="Opens on your name inside the letters, plays your demo, then deals cards, lands your logo and the call to action" onClick={() => update((q) => launchFilm(q), true)}>
        <Icon.film size={14} /> {film ? 'Launch film shots added' : 'Make it a launch film'}
      </button>
    </>
  );
};

// The background palettes, shared by the project panel and the Background layer.
const PaletteField: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project: p, update }) => {
  const peek = usePeek();
  const set = (fn: (q: DemoProject) => DemoProject) => update(fn, true);
  const paletteFn = (name: string) => (q: DemoProject) => ({ ...q, gradient: { ...q.gradient, palette: name } });
  return (
    <>
      <div className="palettes">
        {Object.entries(PALETTES).map(([name, cols]) => (
          <button key={name} className={`palette ${p.gradient.palette === name ? 'on' : ''}`} onClick={() => set(paletteFn(name))} {...peek(name, paletteFn(name))}>
            <span style={{ background: `linear-gradient(120deg, ${cols.join(',')})` }} />
            {name}
          </button>
        ))}
        <button className={`palette ${p.gradient.palette === 'Custom' ? 'on' : ''}`} onClick={() => set((q) => ({ ...q, gradient: { ...q.gradient, palette: 'Custom', colors: paletteOf(q) } }))}>
          <span className="custom-swatch" style={{ background: `linear-gradient(120deg, ${(p.gradient.colors ?? paletteOf(p)).join(',')})` }} />
          Custom
        </button>
      </div>
      {p.gradient.palette === 'Custom' && (
        <Field label="Brand colours" hint="glow · accent · haze">
          <div className="color-row">
            {paletteOf(p).map((col, k) => (
              <label key={k} className="color-pick" style={{ background: col }}>
                <input
                  type="color"
                  value={col}
                  onChange={(e) =>
                    set((q) => {
                      const colors = [...paletteOf(q)] as [string, string, string];
                      colors[k] = e.target.value;
                      return { ...q, gradient: { ...q.gradient, palette: 'Custom', colors } };
                    })
                  }
                />
                <span>{col}</span>
              </label>
            ))}
          </div>
        </Field>
      )}
    </>
  );
};

const CaptionsField: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project: p, update }) => (
  <>
    <div className="seg">
      <button className={!p.captions ? 'on' : ''} onClick={() => update((q) => ({ ...q, captions: undefined }), true)}>Off</button>
      {CAPTION_STYLES.map((c) => (
        <button key={c.key} className={p.captions === c.key ? 'on' : ''} title={c.hint} onClick={() => update((q) => ({ ...q, captions: c.key }), true)}>{c.label}</button>
      ))}
    </div>
    <button className="ghost wide" title="Captions file for YouTube, LinkedIn and players" onClick={() => download(`${(p.title || 'lumora').replace(/\W+/g, '-').toLowerCase()}.srt`, toSrt(p))}>
      <Icon.download size={14} /> Download captions (.srt)
    </button>
  </>
);

const CtaField: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project: p, update }) => (
  <Field label="Call to action" hint="button · link">
    <div className="cta-fields">
      <input value={p.cta?.text ?? ''} placeholder="Start free" onChange={(e) => update((q) => ({ ...q, cta: e.target.value || q.cta?.url ? { text: e.target.value, url: q.cta?.url ?? '' } : undefined }), false)} onBlur={() => update((q) => q, true)} />
      <input value={p.cta?.url ?? ''} placeholder="yourproduct.com/signup" onChange={(e) => update((q) => ({ ...q, cta: { text: q.cta?.text ?? '', url: e.target.value } }), false)} onBlur={() => update((q) => q, true)} />
    </div>
  </Field>
);

// Start from a web page or from one sentence: two ways to fill the whole video at once.
const AutoCreate: React.FC<{ project: DemoProject; update: Props['update'] }> = ({ project, update }) => {
  const { locked } = useProGate();
  const [mode, setMode] = useState<'ai' | 'site'>(locked ? 'site' : 'ai');
  return (
    <>
      <div className="seg two">
        <button className={mode === 'ai' ? 'on' : ''} onClick={() => setMode('ai')}><Icon.sparkle size={13} /> One prompt{locked && <ProLock />}</button>
        <button className={mode === 'site' ? 'on' : ''} onClick={() => setMode('site')}><Icon.link size={13} /> From a website</button>
      </div>
      {mode === 'ai' ? <AutoDirect project={project} update={update} /> : <WebsiteField project={project} update={update} />}
    </>
  );
};

// A titled part of the project panel that folds away; it shows its current value while folded.
const OPEN_KEY = 'lumora.inspector.open';
const readOpen = (): Record<string, boolean> => {
  try {
    return JSON.parse(localStorage.getItem(OPEN_KEY) ?? '{}');
  } catch {
    return {};
  }
};
const Section: React.FC<{ id: string; title: string; summary?: React.ReactNode; open?: boolean; tag?: string; children: React.ReactNode }> = ({ id, title, summary, open: initial = true, tag, children }) => {
  const [open, setOpen] = useState(() => readOpen()[id] ?? initial);
  const toggle = () => {
    setOpen(!open);
    try {
      localStorage.setItem(OPEN_KEY, JSON.stringify({ ...readOpen(), [id]: !open }));
    } catch {
      // private mode: the panel just forgets
    }
  };
  // a search shows every match open
  const shown = open || !!tag;
  return (
    <section className={`sec ${shown ? 'open' : ''}`}>
      <button className="sec-head" aria-expanded={shown} onClick={toggle}>
        <Icon.chevron size={12} />
        <b>{title}</b>
        {tag && <i className="sec-tag">{tag}</i>}
        {summary !== undefined && summary !== '' && <span className="sec-sum">{summary}</span>}
      </button>
      {shown && <div className="sec-body">{children}</div>}
    </section>
  );
};

type TabKey = 'story' | 'look' | 'motion' | 'sound' | 'finish';
const TABS: { key: TabKey; label: string; icon: (p: { size?: number }) => React.ReactElement }[] = [
  { key: 'story', label: 'Story', icon: Icon.type },
  { key: 'look', label: 'Look', icon: Icon.gradient },
  { key: 'motion', label: 'Motion', icon: Icon.camera },
  { key: 'sound', label: 'Sound', icon: Icon.music },
  { key: 'finish', label: 'Finish', icon: Icon.sparkle },
];
const TAB_KEY = 'lumora.inspector.tab';

// The project settings in five tabs, each a short list of folding sections. The search box
// finds a setting in any tab; 1–5 switch tabs and / jumps to the search.
const ProjectPanel: React.FC<{ project: DemoProject; update: Props['update']; select: (s: Selection) => void; setDuration: (d: number) => void; onUpload: () => void; seek?: (t: number) => void }> = ({ project: p, update, select, setDuration, onUpload, seek }) => {
  const set = (fn: (p: DemoProject) => DemoProject) => update(fn, true);
  const peek = usePeek();
  const [tab, setTabState] = useState<TabKey>(() => {
    try {
      const t = localStorage.getItem(TAB_KEY) as TabKey | null;
      return t && TABS.some((x) => x.key === t) ? t : 'story';
    } catch {
      return 'story';
    }
  });
  const setTab = (t: TabKey) => {
    setTabState(t);
    setQuery('');
    try {
      localStorage.setItem(TAB_KEY, t);
    } catch {
      // remembered for this visit only
    }
    document.querySelector('.side')?.scrollTo({ top: 0 });
  };
  const [query, setQuery] = useState('');
  const search = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key === '/') {
        e.preventDefault();
        search.current?.focus();
      } else if (e.key >= '1' && e.key <= '5') setTab(TABS[Number(e.key) - 1].key);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const fx = p.effects ?? {};
  const fxCount = EFFECTS.filter((e) => fxOn(fx, e.key)).length;
  const notes = filmCheck(p);
  const fixes = notes.filter((n) => n.level === 'fix').length;
  const wallpaper = WALLPAPERS.find((w) => w.src === p.backdrop)?.name;
  const label = <T extends { key: string; label: string }>(list: readonly T[], key: string | undefined, fallback: string) => list.find((x) => x.key === key)?.label ?? fallback;
  const video = p.media.kind === 'video';

  type Sec = { id: string; tab: TabKey; title: string; keys: string; summary?: React.ReactNode; open?: boolean; body: React.ReactNode };
  const sections: Sec[] = [
    {
      id: 'screen', tab: 'story', title: 'Screen', keys: 'media recording screenshot replace upload trim speed parts cut still auto zoom',
      summary: video ? 'Screen recording' : p.media.slides && p.media.slides.length > 1 ? `${p.media.slides.length} screenshots` : 'Screenshot',
      body: (
        <>
          <div className="media-card">
            {video ? <video src={resolveSrc(p.media.src)} muted /> : <img src={resolveSrc(p.media.src)} alt="" />}
            <div>
              <b>{video ? 'Screen recording' : p.media.slides && p.media.slides.length > 1 ? `${p.media.slides.length} screenshots` : 'Screenshot'}</b>
              <button className="link" onClick={onUpload}>Replace…</button>
            </div>
          </div>
          {video && <RecordingTrim project={p} set={set} update={update} setDuration={setDuration} />}
          {video && <AutoZoom project={p} update={update} />}
        </>
      ),
    },
    { id: 'auto', tab: 'story', title: 'Create for me', keys: 'ai direction prompt brief website url capture claude write copy', summary: 'AI · website', body: <AutoCreate project={p} update={update} /> },
    {
      id: 'text', tab: 'story', title: 'Words', keys: 'title tagline copy check text headline', summary: p.title,
      body: (
        <>
          <Field label="Title"><input value={p.title} onChange={(e) => set((q) => ({ ...q, title: e.target.value }))} /></Field>
          <Field label="Tagline"><input value={p.tagline} onChange={(e) => set((q) => ({ ...q, tagline: e.target.value }))} /></Field>
          <CopyCheck project={p} />
        </>
      ),
    },
    {
      id: 'end', tab: 'story', title: 'End card', keys: 'logo call to action cta button link signup brand kit team', summary: p.cta?.text || (p.logo ? 'Logo' : 'Title'),
      body: (
        <>
          <LogoField project={p} update={update} />
          <CtaField project={p} update={update} />
          <BrandKitField project={p} update={update} />
        </>
      ),
    },
    { id: 'webcam', tab: 'story', title: 'Webcam', keys: 'webcam camera face bubble presenter corner', summary: p.cam ? 'Bubble' : 'Off', open: false, body: <WebcamField project={p} update={update} /> },

    {
      id: 'format', tab: 'look', title: 'Format', keys: 'format size aspect 16:9 9:16 1:1 vertical square landscape', summary: FORMATS[p.format ?? 'landscape'].label,
      body: (
        <div className="seg">
          {(Object.keys(FORMATS) as Format[]).map((f) => (
            <button key={f} className={(p.format ?? 'landscape') === f ? 'on' : ''} title={FORMATS[f].hint} onClick={() => set((q) => ({ ...q, format: f }))}>
              <span className={`seg-shape ${f}`} />
              {FORMATS[f].label}
            </button>
          ))}
        </div>
      ),
    },
    { id: 'look', tab: 'look', title: 'Look', keys: `look style preset shuffle direction ${LOOKS.map((l) => l.name).join(' ')}`, summary: p.look ?? 'Custom', body: <LookPicker project={p} update={update} /> },
    {
      id: 'device', tab: 'look', title: 'Device', keys: `device frame mockup card ${DEVICES.map((d) => d.label).join(' ')}`, summary: p.device ? label(DEVICES, p.device, 'Card') : 'Card',
      body: (
        <div className="seg">
          <button className={!p.device ? 'on' : ''} onClick={() => set((q) => ({ ...q, device: undefined }))} {...peek('Card', (q) => ({ ...q, device: undefined }))}>Card</button>
          {DEVICES.map((d) => (
            <button key={d.key} title={d.hint} className={p.device === d.key ? 'on' : ''} onClick={() => set((q) => ({ ...q, device: d.key }))} {...peek(d.label, (q) => ({ ...q, device: d.key }))}>{d.label}</button>
          ))}
        </div>
      ),
    },
    {
      id: 'background', tab: 'look', title: 'Background', keys: `background palette colour color brand wallpaper backdrop stage gradient image ${Object.keys(PALETTES).join(' ')}`, summary: wallpaper ?? p.gradient.palette,
      body: (
        <>
          <PaletteField project={p} update={update} />
          <BackdropField project={p} update={update} />
        </>
      ),
    },
    {
      id: 'type', tab: 'look', title: 'Text and callouts', keys: `callout callouts text animation font ${CALLOUT_STYLES.map((c) => c.label).join(' ')} ${TEXT_STYLES.map((t) => t.label).join(' ')}`,
      summary: `${label(CALLOUT_STYLES, p.calloutStyle ?? 'glass', 'Glass')} · ${label(TEXT_STYLES, p.textStyle ?? 'blur', 'Focus')}`,
      body: (
        <>
          <Group label="Callouts">
            <div className="seg">
              {CALLOUT_STYLES.map((cs) => {
                const fn = (q: DemoProject) => ({ ...q, calloutStyle: cs.key === 'glass' ? undefined : cs.key });
                return <button key={cs.key} title={cs.hint} className={(p.calloutStyle ?? 'glass') === cs.key ? 'on' : ''} onClick={() => set(fn)} {...peek(cs.label, fn)}>{cs.label}</button>;
              })}
            </div>
          </Group>
          <TextStylePicker project={p} set={set} />
        </>
      ),
    },

    {
      id: 'camera', tab: 'motion', title: 'Camera move', keys: `camera move motion style ${CAMERA_STYLES.join(' ')}`, summary: `${p.camera.length} keys`,
      body: (
        <>
          <div className="opt-grid">
            {CAMERA_STYLES.map((cs) => {
              const fn = (q: DemoProject) => ({ ...q, look: undefined, camera: cameraForStyle(cs, q.duration) });
              return <button key={cs} className="chip" onClick={() => set(fn)} {...peek(cs, fn)}>{cs}</button>;
            })}
          </div>
          <p className="note">Hover to preview, click to use. Fine-tune the keys on the timeline.</p>
        </>
      ),
    },
    {
      id: 'timing', tab: 'motion', title: 'Length and drop', keys: `length duration seconds beat drop ${DROP_STYLES.map((d) => d.label).join(' ')}`, summary: `${p.duration}s · ${label(DROP_STYLES, p.dropStyle ?? 'pulse', 'Push')}`,
      body: (
        <>
          <Field label="Length"><Slider value={p.duration} min={5} max={60} step={1} fmt={(v) => `${v}s`} onChange={setDuration} /></Field>
          <Group label="Beat drop">
            <div className="seg">
              {DROP_STYLES.map((ds) => {
                const fn = (q: DemoProject) => ({ ...q, dropStyle: ds.key === 'pulse' ? undefined : ds.key });
                return <button key={ds.key} title={ds.hint} className={(p.dropStyle ?? 'pulse') === ds.key ? 'on' : ''} onClick={() => set(fn)} {...peek(ds.label, fn)}>{ds.label}</button>;
              })}
            </div>
          </Group>
        </>
      ),
    },
    { id: 'shots', tab: 'motion', title: 'Shots', keys: `shots shot launch film cut ${SHOT_KINDS.map((k) => k.label).join(' ')}`, summary: p.shots?.length ? `${p.shots.length}` : 'None', body: <ShotsField project={p} update={update} select={select} /> },
    ...(notes.length ? [{ id: 'check', tab: 'motion' as const, title: 'Final check', keys: 'final check tips fix export problems', summary: fixes ? `${fixes} to fix` : `${notes.length} tips`, body: <FilmCheck project={p} select={select} seek={seek} /> }] : []),

    {
      id: 'music', tab: 'sound', title: 'Music', keys: 'music score track song volume beat sync bpm', summary: p.score.name,
      body: (
        <>
          <MusicPicker project={p} update={update} />
          <Field label="Volume"><Slider value={p.score.volume} min={0} max={1} onChange={(volume) => set((q) => ({ ...q, score: { ...q.score, volume } }))} /></Field>
          <BeatSync project={p} update={update} />
        </>
      ),
    },
    { id: 'voice', tab: 'sound', title: 'Voice', keys: 'voiceover voice narration script ai voice speech recording sound transcript clean filler', summary: p.narration?.src ? 'Voiceover' : p.narration?.script ? 'Script' : video && p.media.sound !== undefined ? 'Recording' : 'None', body: <VoicePanel project={p} update={update} setDuration={setDuration} seek={seek} /> },
    { id: 'captions', tab: 'sound', title: 'Captions', keys: `captions subtitles srt burned ${CAPTION_STYLES.map((c) => c.label).join(' ')}`, summary: p.captions ? label(CAPTION_STYLES, p.captions, 'On') : 'Off', body: <CaptionsField project={p} update={update} /> },

    { id: 'effects', tab: 'finish', title: 'Effects', keys: `effects sound effects sfx grain ${EFFECTS.map((e) => e.label).join(' ')}`, summary: fxCount ? `${fxCount} on` : 'None', body: <EffectsPanel project={p} set={set} /> },
    {
      id: 'light', tab: 'finish', title: 'Light and focus', keys: 'glow depth of field blur vignette light focus', summary: `Glow ${p.glow.toFixed(1)}`,
      body: (
        <>
          <Field label="Glow"><Slider value={p.glow} min={0} max={1.5} onChange={(glow) => set((q) => ({ ...q, glow }))} /></Field>
          <Field label="Depth of field" hint="blur px"><Slider value={p.dof} min={0} max={20} step={0.5} fmt={(v) => `${v}px`} onChange={(dof) => set((q) => ({ ...q, dof }))} /></Field>
          <Field label="Vignette"><Slider value={fx.vignette ?? 0.75} min={0} max={1} onChange={(vignette) => set((q) => ({ ...q, effects: { ...q.effects, vignette } }))} /></Field>
        </>
      ),
    },
  ];

  const q = query.trim().toLowerCase();
  const words = q.split(/\s+/).filter(Boolean);
  const shown = q ? sections.filter((x) => words.every((w) => `${x.title} ${x.keys}`.toLowerCase().includes(w))) : sections.filter((x) => x.tab === tab);
  const tabLabel = (k: TabKey) => TABS.find((t) => t.key === k)!.label;
  // point at the exact control a search found, e.g. the Film grain toggle inside Effects
  const body = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const hits = q ? Array.from(body.current?.querySelectorAll<HTMLElement>('button:not(.sec-head), .field > span') ?? []).filter((el) => el.textContent?.toLowerCase().includes(q)) : [];
    hits.forEach((el) => el.classList.add('hit'));
    return () => hits.forEach((el) => el.classList.remove('hit'));
  });

  return (
    <div className="inspector project">
      <div className="insp-top">
        <label className="insp-search">
          <Icon.search size={14} />
          <input ref={search} value={query} placeholder="Find a setting" aria-label="Find a setting" onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => { if (e.key === 'Escape') { setQuery(''); e.currentTarget.blur(); } }} />
          {query ? <button className="mini" title="Clear" onClick={() => setQuery('')}>✕</button> : <kbd>/</kbd>}
        </label>
        <nav className="insp-tabs" role="tablist">
          {TABS.map((t, i) => (
            <button key={t.key} role="tab" aria-selected={!q && tab === t.key} className={!q && tab === t.key ? 'on' : ''} title={`${t.label} (${i + 1})`} onClick={() => setTab(t.key)}>
              <t.icon size={15} />
              {t.label}
            </button>
          ))}
        </nav>
      </div>
      <div className="insp-body" ref={body}>
        {shown.map((x) => (
          <Section key={x.id} id={x.id} title={x.title} summary={x.summary} open={x.open} tag={q ? tabLabel(x.tab) : undefined}>
            {x.body}
          </Section>
        ))}
        {q && !shown.length && <p className="note insp-empty">No setting matches “{query}”.</p>}
      </div>
      {!q && <p className="note insp-foot">Select a clip, keyframe or section on the timeline to edit it. Drag clips to move them, drag their edges to trim.</p>}
    </div>
  );
};
