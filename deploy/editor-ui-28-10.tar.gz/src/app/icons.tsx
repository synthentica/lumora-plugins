import React from 'react';

const I: React.FC<{ d: string; size?: number; fill?: boolean }> = ({ d, size = 16, fill }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);

export const Icon = {
  pointer: (p: { size?: number }) => <I {...p} fill d="M5 3l14 8-6 1.5L10 19z" />,
  scissors: (p: { size?: number }) => <I {...p} d="M6 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12" />,
  plus: (p: { size?: number }) => <I {...p} d="M12 5v14M5 12h14" />,
  chevron: (p: { size?: number }) => <I {...p} d="M6 9l6 6 6-6" />,
  back: (p: { size?: number }) => <I {...p} d="M15 18l-6-6 6-6" />,
  search: (p: { size?: number }) => <I {...p} d="M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-4.3-4.3" />,
  shuffle: (p: { size?: number }) => <I {...p} d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5" />,
  film: (p: { size?: number }) => <I {...p} d="M4 4h16v16H4zM4 9h16M4 15h16M9 4v5M15 4v5M9 15v5M15 15v5" />,
  lock: (p: { size?: number }) => <I {...p} d="M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4" />,
  unlock: (p: { size?: number }) => <I {...p} d="M5 11h14v10H5zM8 11V7a4 4 0 0 1 7.5-2" />,
  eye: (p: { size?: number }) => <I {...p} d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />,
  eyeOff: (p: { size?: number }) => <I {...p} d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c7 0 11 7 11 7a18 18 0 0 1-3.2 3.9M6.6 6.6A18 18 0 0 0 1 12s4 7 11 7a10 10 0 0 0 5.4-1.6" />,
  sections: (p: { size?: number }) => <I {...p} d="M4 4v16M20 4v16M8 12h8M10 9l-2 3 2 3M14 9l2 3-2 3" />,
  camera: (p: { size?: number }) => <I {...p} d="M3 7h12v10H3zM15 10l6-3v10l-6-3" />,
  scan: (p: { size?: number }) => <I {...p} d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />,
  type: (p: { size?: number }) => <I {...p} d="M4 6V4h16v2M12 4v16M9 20h6" />,
  callout: (p: { size?: number }) => <I {...p} d="M4 4h16v11H9l-5 4z" />,
  gradient: (p: { size?: number }) => <I {...p} d="M12 2l2.4 4.2L19 5l-1.2 4.6L22 12l-4.2 2.4L19 19l-4.6-1.2L12 22l-2.4-4.2L5 19l1.2-4.6L2 12l4.2-2.4L5 5l4.6 1.2z" />,
  music: (p: { size?: number }) => <I {...p} d="M9 18V5l12-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM21 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />,
  skipStart: (p: { size?: number }) => <I {...p} fill d="M6 5h2v14H6zM20 5v14L9 12z" />,
  skipEnd: (p: { size?: number }) => <I {...p} fill d="M16 5h2v14h-2zM4 5v14l11-7z" />,
  stepBack: (p: { size?: number }) => <I {...p} d="M17 6v12L8 12zM6 6v12" />,
  stepFwd: (p: { size?: number }) => <I {...p} d="M7 6v12l9-6zM18 6v12" />,
  play: (p: { size?: number }) => <I {...p} fill d="M7 4v16l13-8z" />,
  pause: (p: { size?: number }) => <I {...p} fill d="M6 4h4v16H6zM14 4h4v16h-4z" />,
  stop: (p: { size?: number }) => <I {...p} fill d="M6 6h12v12H6z" />,
  record: (p: { size?: number }) => <I {...p} d="M12 19a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />,
  upload: (p: { size?: number }) => <I {...p} d="M12 16V4M7 9l5-5 5 5M4 20h16" />,
  sparkle: (p: { size?: number }) => <I {...p} d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z" />,
  download: (p: { size?: number }) => <I {...p} d="M12 4v12M7 11l5 5 5-5M4 20h16" />,
  link: (p: { size?: number }) => <I {...p} d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1" />,
  copy: (p: { size?: number }) => <I {...p} d="M9 9h11v11H9zM5 15H4V4h11v1" />,
  shot: (p: { size?: number }) => <I {...p} d="M3 5h18v14H3zM7 5v14M17 5v14M3 9h4M3 15h4M17 9h4M17 15h4" />,
  zoom: (p: { size?: number }) => <I {...p} d="M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-5-5M11 8v6M8 11h6" />,
  trash: (p: { size?: number }) => <I {...p} d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13" />,
  undo: (p: { size?: number }) => <I {...p} d="M9 14L4 9l5-5M4 9h11a5 5 0 0 1 0 10h-3" />,
  redo: (p: { size?: number }) => <I {...p} d="M15 14l5-5-5-5M20 9H9a5 5 0 0 0 0 10h3" />,
};
