import fs from 'node:fs';
import { privacyMarkdown, supportMarkdown, termsMarkdown } from './legal';
import { createHash } from 'node:crypto';
import path from 'node:path';
import type { Express, Request, Response, NextFunction } from 'express';
import { marked } from 'marked';
import { ENTITY, FAQ, FEATURES, FIT, PLANS, SITE, USES } from '../src/app/site';
import { countTraffic, getRender, renderSize } from './store';
import { renderOgCard } from './render';

// The crawlable side of Lumora: the blog, agent docs, robots/sitemap/llms.txt, social cards
// and the head of the landing and share pages. Plain server-rendered HTML, because most AI
// crawlers don't run JavaScript and the app itself is a client-side SPA.

type Faq = { q: string; a: string };
export type Post = { path: string; schema?: string; label?: string; pinned: boolean; author: string; slug: string; title: string; description: string; date: string; updated?: string; keywords: string[]; faq: Faq[]; md: string; html: string; minutes: number; toc: { id: string; text: string }[] };

// Posts write {{SITE_URL}} where commands need this deployment's address.
const withBase = (s: string, base: string) => s.replaceAll('{{SITE_URL}}', base);
// Pages write {{PLANS}} where the current plans go, so prices live in one place (src/app/site.ts).
const plansTable = () =>
  `| Plan | Price | What you get |\n|---|---|---|\n${PLANS.map((p) => `| ${p.name} | ${p.price}${p.amount ? ' / month' : ''} | ${p.items.join(', ')} |`).join('\n')}`;
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/<[^>]+>/g, '')
    .replace(/&[a-z]+;/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');

// Frontmatter: the small YAML subset the posts use (scalars, [inline, lists], and a faq list of q/a maps).
const scalar = (v: string): string => {
  v = v.trim();
  if (v.startsWith('"')) return JSON.parse(v);
  if (v.startsWith("'")) return v.slice(1, -1).replace(/''/g, "'");
  return v;
};
const parseFrontmatter = (src: string) => {
  const m = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?/.exec(src);
  if (!m) return { data: {} as Record<string, unknown>, body: src };
  const data: Record<string, unknown> = {};
  let list: Record<string, string>[] | null = null;
  for (const line of m[1].split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const item = /^\s+-\s+(\w+):\s*(.*)$/.exec(line);
    const cont = /^\s{3,}(\w+):\s*(.*)$/.exec(line);
    const top = /^(\w+):\s*(.*)$/.exec(line);
    if (item && list) list.push({ [item[1]]: scalar(item[2]) });
    else if (cont && list?.length) list[list.length - 1][cont[1]] = scalar(cont[2]);
    else if (top) {
      const [, key, raw] = top;
      if (!raw.trim()) data[key] = list = [];
      else if (raw.trim().startsWith('[')) {
        list = null;
        data[key] = raw
          .trim()
          .slice(1, -1)
          .split(',')
          .map((x) => scalar(x))
          .filter(Boolean);
      } else {
        list = null;
        data[key] = scalar(raw);
      }
    }
  }
  return { data, body: src.slice(m[0].length) };
};

// Example clips in posts load and play only while on screen, and stay still for people who
// ask for reduced motion.
const CLIP_SCRIPT = `<script>(() => {
  const clips = document.querySelectorAll('.prose video[data-autoplay]');
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver((es) => es.forEach((e) => (e.isIntersecting ? e.target.play().catch(() => {}) : e.target.pause())), { rootMargin: '200px' });
  clips.forEach((v) => io.observe(v));
})();</script>`;

// Byline for posts that don't name their own author.
const DEFAULT_AUTHOR = 'Mika from Lumora';
const personLd = (base: string, name: string) => ({ '@type': 'Person', name: name.replace(/ from Lumora$/, ''), worksFor: ORG(base) });

// Blog posts live in content/blog; standalone pages (pricing, about, comparisons) in content/pages,
// each with its own `path:` in the frontmatter. Both are markdown, parsed the same way.
const caches = new Map<string, { at: number; posts: Post[] }>();
let blogDir = '';
let pagesDir = '';
const loadDir = (dir: string, pathOf: (slug: string, data: Record<string, unknown>) => string): Post[] => {
  const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.endsWith('.md')) : [];
  const stamp = Math.max(0, ...files.map((f) => fs.statSync(path.join(dir, f)).mtimeMs));
  const cache = caches.get(dir);
  if (cache && cache.at === stamp + files.length) return cache.posts;
  const posts = files.map((f) => {
    const parsed = parseFrontmatter(fs.readFileSync(path.join(dir, f), 'utf8'));
    const data = parsed.data;
    const body = parsed.body.replaceAll('{{PLANS}}', plansTable());
    const toc: Post['toc'] = [];
    const renderer = new marked.Renderer();
    renderer.heading = function ({ tokens, depth }) {
      const text = this.parser.parseInline(tokens);
      const id = slugify(text);
      if (depth === 2) toc.push({ id, text: text.replace(/<[^>]+>/g, '') });
      return `<h${depth} id="${id}"><a class="anchor" href="#${id}" aria-hidden="true">#</a>${text}</h${depth}>\n`;
    };
    renderer.link = function ({ href, title, tokens }) {
      const text = this.parser.parseInline(tokens);
      const external = /^https?:\/\//.test(href);
      return `<a href="${esc(href)}"${title ? ` title="${esc(title)}"` : ''}${external ? ' rel="noopener" target="_blank"' : ''}>${text}</a>`;
    };
    renderer.table = function (token) {
      return `<div class="table-wrap">${marked.Renderer.prototype.table.call(this, token)}</div>`;
    };
    const md = body.replace(/^\s*#\s+.*\n/, ''); // the title is rendered from frontmatter
    const html = marked.parse(md, { renderer, async: false }) as string;
    const words = md.split(/\s+/).length;
    return {
      path: pathOf(f.replace(/\.md$/, ''), data),
      schema: data.schema ? String(data.schema) : undefined,
      label: data.label ? String(data.label) : undefined,
      pinned: data.pinned === 'true',
      author: String(data.author ?? DEFAULT_AUTHOR),
      slug: f.replace(/\.md$/, ''),
      title: String(data.title ?? f),
      description: String(data.description ?? ''),
      date: String(data.date ?? '2026-10-17'),
      updated: data.updated ? String(data.updated) : undefined,
      keywords: (data.keywords as string[]) ?? [],
      faq: ((data.faq as Faq[]) ?? []).filter((x) => x.q && x.a),
      md: body,
      html,
      minutes: Math.max(1, Math.round(words / 230)),
      toc,
    };
  });
  // pinned (pillar) posts first, then newest
  posts.sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.date.localeCompare(a.date) || a.title.localeCompare(b.title));
  caches.set(dir, { at: stamp + files.length, posts });
  return posts;
};
export const loadPosts = () => loadDir(blogDir, (slug) => `/blog/${slug}`);
export const loadPages = () => loadDir(pagesDir, (slug, data) => String(data.path ?? `/${slug}`)).sort((a, b) => a.path.localeCompare(b.path));

// --- Page shell -----------------------------------------------------------------
type Head = { author?: string; title: string; description: string; path: string; image?: string; type?: string; jsonLd?: object[]; noindex?: boolean; extra?: string };
const headTags = (base: string, h: Head) => {
  const url = base + h.path;
  const image = h.image ?? `${base}/og/home.jpg`;
  return [
    `<title>${esc(h.title)}</title>`,
    `<meta name="description" content="${esc(h.description)}">`,
    `<link rel="canonical" href="${esc(url)}">`,
    h.noindex ? '<meta name="robots" content="noindex">' : '<meta name="robots" content="index, follow, max-image-preview:large">',
    `<meta property="og:site_name" content="Lumora">`,
    h.author ? `<meta name="author" content="${esc(h.author)}">` : '',
    `<meta property="og:type" content="${h.type ?? 'website'}">`,
    `<meta property="og:title" content="${esc(h.title)}">`,
    `<meta property="og:description" content="${esc(h.description)}">`,
    `<meta property="og:url" content="${esc(url)}">`,
    `<meta property="og:image" content="${esc(image)}">`,
    `<meta name="twitter:card" content="summary_large_image">`,
    `<meta name="twitter:title" content="${esc(h.title)}">`,
    `<meta name="twitter:description" content="${esc(h.description)}">`,
    `<meta name="twitter:image" content="${esc(image)}">`,
    `<link rel="alternate" type="application/rss+xml" title="Lumora blog" href="${base}/blog/rss.xml">`,
    ...(h.jsonLd ?? []).map((j) => `<script type="application/ld+json">${JSON.stringify(j).replace(/</g, '\\u003c')}</script>`),
    h.extra ?? '',
  ].join('\n    ');
};

const nav = `<nav class="sr-nav">
  <a class="lp-mark" href="/">Lumora<span class="rec"><i></i> REC</span></a>
  <div class="lp-links">
    <a href="/blog">Blog</a>
    <a href="/compare">Compare</a>
    <a href="/docs/agents">Agents</a>
    <a href="/pricing">Pricing</a>
    <a class="lp-btn" href="/#/editor">Open editor <span aria-hidden="true">→</span></a>
  </div>
</nav>`;
const footer = `<footer class="lp-foot">
  <span class="lp-mark small">Lumora</span>
  <span>© ${new Date().getFullYear()} Lumora</span>
  <a href="/blog">Blog</a>
  <a href="/pricing">Pricing</a>
  <a href="/compare">Compare</a>
  <a href="/docs/agents">Agents &amp; MCP</a>
  <a href="/about">About</a>
  <a href="/llms.txt">llms.txt</a>
  <a href="/terms">Terms</a>
  <a href="/privacy">Privacy</a>
  <a href="/support">Support</a>
</footer>`;

const shell = (base: string, h: Head, body: string) => `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/favicon.png">
    <link rel="preload" href="/fonts/instrument-serif-latin-400-normal.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="/site.css">
    ${headTags(base, h)}
  </head>
  <body class="sr site">
    ${nav}
    ${body}
    ${footer}
  </body>
</html>`;

const fmtDate = (d: string) => new Date(`${d}T12:00:00Z`).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });

const ORG = (base: string) => ({
  '@type': 'Organization',
  '@id': `${base}/#org`,
  name: 'Lumora',
  alternateName: ENTITY.alternateName,
  url: `${base}/`,
  logo: `${base}/favicon.png`,
  description: SITE.description,
  disambiguatingDescription: ENTITY.disambiguation,
  foundingDate: ENTITY.foundingDate,
  founder: { '@type': 'Person', name: ENTITY.founder },
  ...(ENTITY.sameAs.length ? { sameAs: ENTITY.sameAs } : {}),
});
const faqLd = (faq: readonly Faq[]) => ({
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faq.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })),
});
const crumbs = (base: string, items: [string, string][]) => ({
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: items.map(([name, p], i) => ({ '@type': 'ListItem', position: i + 1, name, item: base + p })),
});

export const homeJsonLd = (base: string) => [
  { '@context': 'https://schema.org', ...ORG(base) },
  { '@context': 'https://schema.org', '@type': 'WebSite', name: 'Lumora', url: `${base}/`, publisher: { '@id': `${base}/#org` } },
  {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    '@id': `${base}/#app`,
    name: 'Lumora',
    alternateName: ENTITY.alternateName,
    url: `${base}/`,
    disambiguatingDescription: ENTITY.disambiguation,
    isAccessibleForFree: true,
    applicationCategory: 'MultimediaApplication',
    applicationSubCategory: 'Video editor',
    operatingSystem: 'Web browser (Windows, macOS, Linux, ChromeOS)',
    description: SITE.description,
    image: `${base}/og/home.jpg`,
    screenshot: `${base}/landing/after.jpg`,
    video: {
      '@type': 'VideoObject',
      name: 'A screen recording directed by Lumora',
      description: 'The same screen recording before and after Lumora: auto zoom, 3D camera, callouts and a beat-synced cut.',
      thumbnailUrl: `${base}/landing/after.jpg`,
      contentUrl: `${base}/landing/after.webm`,
      uploadDate: '2026-10-17',
    },
    featureList: FEATURES.map(([n, unit, text]) => `${n} ${unit}: ${text}`),
    offers: PLANS.map((p) => ({ '@type': 'Offer', name: p.name, price: String(p.amount), priceCurrency: 'EUR', url: `${base}/pricing`, description: p.items.join(', ') })),
    publisher: { '@id': `${base}/#org` },
  },
  faqLd(FAQ),
];

// --- Pages ----------------------------------------------------------------------
const postCard = (p: Post) => `<a class="post-card" href="/blog/${p.slug}">
      <span class="post-meta">${fmtDate(p.date)} · ${p.minutes} min read</span>
      <h2>${esc(p.title)}</h2>
      <p>${esc(p.description)}</p>
    </a>`;

const blogIndex = (base: string, posts: Post[]) =>
  shell(
    base,
    {
      title: 'Blog: making product demo and launch videos · Lumora',
      description: 'Guides on product demo videos, launch videos, video specs and making videos with coding agents, from the team behind Lumora.',
      path: '/blog',
      jsonLd: [
        {
          '@context': 'https://schema.org',
          '@type': 'Blog',
          name: 'Lumora blog',
          url: `${base}/blog`,
          publisher: ORG(base),
          blogPost: posts.map((p) => ({ '@type': 'BlogPosting', headline: p.title, url: `${base}/blog/${p.slug}`, datePublished: p.date })),
        },
      ],
    },
    `<main class="blog">
    <header class="blog-head">
      <p class="lp-kicker">The cutting room</p>
      <h1>Notes on making <em>software</em> look good on video.</h1>
      <p class="lede">How-tos, specs and launch checklists for product demo videos. Written by people who make them.</p>
    </header>
    <div class="post-list">
    ${posts.map(postCard).join('\n    ')}
    </div>
  </main>`,
  );

const postPage = (base: string, p: Post, all: Post[]) => {
  const related = all.filter((x) => x.slug !== p.slug).slice(0, 3);
  const image = `${base}/og/blog/${p.slug}.jpg`;
  return shell(
    base,
    {
      title: `${p.title} · Lumora`,
      description: p.description,
      path: `/blog/${p.slug}`,
      type: 'article',
      author: p.author,
      image,
      extra: `<link rel="alternate" type="text/markdown" href="${base}/blog/${p.slug}.md">\n    <meta property="article:published_time" content="${p.date}">`,
      jsonLd: [
        {
          '@context': 'https://schema.org',
          '@type': 'BlogPosting',
          headline: p.title,
          description: p.description,
          image,
          datePublished: p.date,
          dateModified: p.updated ?? p.date,
          keywords: p.keywords.join(', '),
          wordCount: p.md.split(/\s+/).length,
          author: personLd(base, p.author),
          publisher: ORG(base),
          mainEntityOfPage: `${base}/blog/${p.slug}`,
        },
        crumbs(base, [
          ['Lumora', '/'],
          ['Blog', '/blog'],
          [p.title, `/blog/${p.slug}`],
        ]),
        ...(p.faq.length ? [faqLd(p.faq)] : []),
      ],
    },
    `<main class="post">
    <header class="post-head">
      <p class="post-meta"><a href="/blog">Blog</a> · By ${esc(p.author)} · <time datetime="${p.date}">${fmtDate(p.date)}</time>${p.updated ? ` · updated <time datetime="${p.updated}">${fmtDate(p.updated)}</time>` : ''} · ${p.minutes} min read</p>
      <h1>${esc(p.title)}</h1>
      <p class="lede">${esc(p.description)}</p>
    </header>
    <div class="post-grid">
      ${
        p.toc.length > 2
          ? `<aside class="toc"><span class="ed-label">On this page</span><ol>${p.toc.map((t) => `<li><a href="#${t.id}">${esc(t.text)}</a></li>`).join('')}</ol></aside>`
          : '<aside></aside>'
      }
      <article class="prose">
        ${withBase(p.html, base)}
        ${
          p.faq.length
            ? `<section class="faq" id="faq"><h2>FAQ</h2>${p.faq.map((f) => `<details open><summary>${esc(f.q)}</summary><p>${esc(f.a)}</p></details>`).join('')}</section>`
            : ''
        }
        <aside class="post-cta">
          <div>
            <b>Turn a screenshot into a launch video.</b>
            <span>Lumora adds the camera moves, callouts, captions and music. Free to start, in the browser.</span>
          </div>
          <a class="lp-btn" href="/?ref=blog-${p.slug}#/editor">Try Lumora free <span aria-hidden="true">→</span></a>
        </aside>
      </article>
    </div>
    ${related.length ? `<section class="related"><span class="ed-label">Read next</span><div class="post-list">${related.map(postCard).join('')}</div></section>` : ''}
  </main>${p.html.includes('data-autoplay') ? CLIP_SCRIPT : ''}`,
  );
};

const docsPage = (base: string, md: string) => {
  const html = marked.parse(md, { async: false }) as string;
  return shell(
    base,
    {
      title: 'Make videos from Claude Code, Codex and any MCP client · Lumora',
      description: 'Lumora has a hosted MCP server, plugins for Claude Code, Claude Desktop and Codex, and a REST API. Agents create, preview and render demo videos from a JSON spec.',
      path: '/docs/agents',
      jsonLd: [crumbs(base, [['Lumora', '/'], ['Agents & MCP', '/docs/agents']])],
    },
    `<main class="post"><div class="post-grid"><aside></aside><article class="prose">${html}</article></div></main>`,
  );
};

// Standalone pages: pricing, about, the comparisons. Same reading layout as a post, no byline.
const crumbsFor = (p: Post, pages: Post[]): [string, string][] => {
  const trail: [string, string][] = [['Lumora', '/']];
  const parts = p.path.split('/').filter(Boolean);
  for (let i = 1; i < parts.length; i++) {
    const up = '/' + parts.slice(0, i).join('/');
    const parent = pages.find((x) => x.path === up);
    if (parent) trail.push([parent.label ?? parent.title, up]);
  }
  trail.push([p.label ?? p.title, p.path]);
  return trail;
};
const contentPage = (base: string, p: Post, pages: Post[]) => {
  const updated = p.updated ?? p.date;
  // siblings under the same parent (other comparisons), or the children of a hub page
  const parentPath = p.path.split('/').slice(0, -1).join('/');
  const children = pages.filter((x) => x.path.startsWith(p.path + '/'));
  const siblings = parentPath ? pages.filter((x) => x.path !== p.path && x.path.startsWith(parentPath + '/')) : [];
  const more = (children.length ? children : siblings).slice(0, 6);
  return shell(
    base,
    {
      title: `${p.title} · Lumora`,
      description: p.description,
      path: p.path,
      extra: `<link rel="alternate" type="text/markdown" href="${base}${p.path}.md">`,
      jsonLd: [
        {
          '@context': 'https://schema.org',
          '@type': p.schema ?? 'WebPage',
          name: p.title,
          description: p.description,
          url: base + p.path,
          dateModified: updated,
          inLanguage: 'en',
          isPartOf: { '@type': 'WebSite', name: 'Lumora', url: `${base}/` },
          about: { '@id': `${base}/#app` },
          publisher: ORG(base),
          ...(children.length ? { mainEntity: { '@type': 'ItemList', itemListElement: children.map((c, i) => ({ '@type': 'ListItem', position: i + 1, name: c.title, url: base + c.path })) } } : {}),
        },
        crumbs(base, crumbsFor(p, pages)),
        ...(p.faq.length ? [faqLd(p.faq)] : []),
      ],
    },
    `<main class="post">
    <header class="post-head">
      <p class="post-meta">${crumbsFor(p, pages)
        .slice(0, -1)
        .map(([n, u]) => `<a href="${u}">${esc(n)}</a>`)
        .join(' · ')} · Updated <time datetime="${updated}">${fmtDate(updated)}</time></p>
      <h1>${esc(p.title)}</h1>
      <p class="lede">${esc(p.description)}</p>
    </header>
    <div class="post-grid">
      ${
        p.toc.length > 2
          ? `<aside class="toc"><span class="ed-label">On this page</span><ol>${p.toc.map((t) => `<li><a href="#${t.id}">${esc(t.text)}</a></li>`).join('')}</ol></aside>`
          : '<aside></aside>'
      }
      <article class="prose">
        ${withBase(p.html, base)}
        ${
          p.faq.length
            ? `<section class="faq" id="faq"><h2>FAQ</h2>${p.faq.map((f) => `<details open><summary>${esc(f.q)}</summary><p>${esc(f.a)}</p></details>`).join('')}</section>`
            : ''
        }
        <aside class="post-cta">
          <div>
            <b>Try it on your own recording.</b>
            <span>Free to start, in the browser, on any computer. No credit card.</span>
          </div>
          <a class="lp-btn" href="/?ref=page${p.path.replace(/\//g, '-')}#/editor">Open Lumora <span aria-hidden="true">→</span></a>
        </aside>
      </article>
    </div>
    ${more.length ? `<section class="related"><span class="ed-label">${children.length ? 'Comparisons' : 'More comparisons'}</span><div class="post-list">${more.map((x) => `<a class="post-card" href="${x.path}"><h2>${esc(x.title)}</h2><p>${esc(x.description)}</p></a>`).join('')}</div></section>` : ''}
  </main>`,
  );
};

const legalPage = (base: string, path: string, title: string, description: string, md: string) =>
  shell(
    base,
    { title: `${title} · Lumora`, description, path, jsonLd: [crumbs(base, [['Lumora', '/'], [title, path]])] },
    `<main class="post"><div class="post-grid"><aside></aside><article class="prose">${marked.parse(md, { async: false }) as string}</article></div></main>`,
  );

// What agents and assistants read. Kept factual; mirrors the landing page.
export const agentsMarkdown = (base: string) => `# Lumora for coding agents

Lumora turns screenshots and screen recordings into cinematic product demo videos. Agents can do everything a person can in the editor through MCP or the REST API.

## Connect

| Client | How |
|---|---|
| Claude (claude.ai, Desktop, mobile, Cowork) | Settings → Connectors → Add custom connector → \`${base}/mcp\`, then **Connect** and sign in to Lumora |
| ChatGPT | Add Lumora as an app with the address \`${base}/mcp\` and sign in to Lumora |
| Claude Code | \`claude mcp add --transport http lumora ${base}/mcp\`, then \`/mcp\` → lumora → Authenticate. Or the plugin: \`/plugin install lumora --marketplace synthentica/lumora-plugins\` |
| Codex | \`codex plugin marketplace add synthentica/lumora-plugins\` and \`codex plugin add lumora@lumora\`, or \`[mcp_servers.lumora] url = "${base}/mcp"\` in \`~/.codex/config.toml\` and \`codex mcp login lumora\` |
| Any MCP client (streamable HTTP) | \`${base}/mcp\` with OAuth 2.1 (discovery at \`/.well-known/oauth-protected-resource\`, dynamic client registration and client ID metadata documents), or \`Authorization: Bearer <API key>\` |

Signing in with OAuth opens a Lumora page where you sign in or create a free account and allow the connection. For scripts and CI, create an API key in Lumora under **Account settings → API keys for agents** instead.

## Tools

| Tool | What it does |
|---|---|
| \`list_styles\` | Looks, camera styles, effects, palettes, caption styles, devices, voices and export formats |
| \`upload_media\` | Upload a screenshot, recording or music track (local path, URL or base64) |
| \`create_video\` | Create a video from a spec or a one-line brief (AI direction writes callouts, script and CTA) |
| \`update_video\` | Change any part of the spec |
| \`get_video\`, \`list_videos\` | Read specs back |
| \`preview_frame\` | Render one frame as an image to check framing before rendering |
| \`render_video\` | Render MP4, GIF or WebM and return a share link |
| \`render_status\` | Poll a render |
| \`save_brand_kit\` | Save the team's logo, colours, music and call to action; use it with \`brandKit\` in \`create_video\` (Team plan) |

## Video spec (example)

\`\`\`json
{
  "name": "Pulse 2.4 release",
  "media": { "url": "/uploads/<id from upload_media>.png" },
  "title": "Churn alerts",
  "brief": "Pulse now alerts you when churn spikes",
  "look": "Launch day",
  "format": "landscape",
  "script": "Pulse 2.4 watches churn for you. When it spikes, you hear about it first.",
  "captions": "pop",
  "device": "macbook",
  "cta": { "text": "Try Pulse", "url": "https://example.com" }
}
\`\`\`

Upload media first with \`upload_media\` (a URL or base64 on the hosted server) and pass the returned \`/uploads/...\` URL, or pass \`"website": "https://yourproduct.com"\` instead and Lumora screenshots the page and takes its colours, font, name and icon. \`"launchFilm": true\` turns the demo into a launch film (name inside the letters, card deal, logo lockup, call to action); \`shots\` places full-frame shots yourself, \`sfxStyle\` (\`minimal\`, \`soft\`, \`punchy\`) sets how the sound effects hit, and the result's \`filmCheck\` lists what to fix before rendering. \`render_video\` takes \`music: false\` and \`package: true\` (a zip of clips, audio stems, captions and a timeline for further editing). Formats are \`landscape\`, \`vertical\` and \`square\`. Call \`list_styles\` for the current option names. A typical release flow: build the feature, screenshot the changed screen, \`create_video\` with a brief from the changelog entry, \`preview_frame\` at the middle, \`render_video\`, then post the share link in the release notes.

## REST API

The same operations are plain HTTP under \`${base}/api\`: \`GET /api/catalog\`, \`POST /api/videos\`, \`PATCH /api/videos/:id\`, \`GET /api/videos/:id/frame?t=\`, \`POST /api/videos/:id/render\`, \`GET /api/jobs/:id\`, \`POST /api/upload/url\`, \`POST /api/capture\`.
`;

const llmsTxt = (base: string, posts: Post[], pages: Post[] = []) => `# Lumora

> ${SITE.description}

Lumora is a web app for software teams, founders and developer advocates. You record your screen in the browser (or bring a recording or screenshots), and Lumora directs it into a finished video with a 3D camera, effects, captions, voiceover and music cut to the beat. Coding agents can make videos through its MCP server.

Which Lumora: ${ENTITY.disambiguation}

## Product

- [Home](${base}/): what Lumora does, looks, pricing and FAQ
${pages.map((p) => `- [${p.title}](${base}${p.path}.md): ${p.description}`).join('\n')}
- [Agents & MCP](${base}/docs/agents.md): MCP server, Claude Code / Codex plugins, tools and the video spec
- [Full text for LLMs](${base}/llms-full.txt): everything below in one file

## When Lumora is a good fit

${FIT.good.map((x) => `- ${x}`).join('\n')}

## When another tool fits better

${FIT.poor.map((x) => `- ${x}`).join('\n')}

## Key facts

${FEATURES.map(([n, unit, text]) => `- ${n} ${unit}: ${text}`).join('\n')}
- Pricing: ${PLANS.map((p) => `${p.name} ${p.price}/month (${p.items.join(', ')})`).join('; ')}
- Runs in any modern browser on Windows, macOS, Linux and ChromeOS. Videos up to 2 minutes; 16:9, 9:16 and 1:1.

## Blog

${posts.map((p) => `- [${p.title}](${base}/blog/${p.slug}.md): ${p.description}`).join('\n')}
`;

const llmsFull = (base: string, posts: Post[], pages: Post[]) =>
  `${llmsTxt(base, posts, pages)}
## FAQ

${FAQ.map((f) => `### ${f.q}\n\n${f.a}`).join('\n\n')}

## Use cases

${USES.map(([t, d]) => `- ${t}: ${d}`).join('\n')}

${agentsMarkdown(base)}
${pages.map((p) => `\n---\n\n# ${p.title}\n\nSource: ${base}${p.path} (updated ${p.updated ?? p.date})\n\n${withBase(p.md.replace(/^\s*#\s+.*\n/, ''), base)}`).join('\n')}
${posts.map((p) => `\n---\n\n# ${p.title}\n\nSource: ${base}/blog/${p.slug} (by ${p.author}, published ${p.date})\n\n${withBase(p.md.replace(/^\s*#\s+.*\n/, ''), base)}`).join('\n')}
`;

const siteUrls = (posts: Post[], pages: Post[]): [string, string][] => {
  const dates = [...posts, ...pages].map((p) => p.updated ?? p.date).sort();
  const newest = dates[dates.length - 1] ?? new Date().toISOString().slice(0, 10);
  return [
    ['/', newest],
    ['/blog', newest],
    ['/docs/agents', newest],
    ['/support', newest],
    ['/privacy', newest],
    ['/terms', newest],
    ...pages.map((p) => [p.path, p.updated ?? p.date] as [string, string]),
    ...posts.map((p) => [`/blog/${p.slug}`, p.updated ?? p.date] as [string, string]),
  ];
};
const sitemap = (base: string, posts: Post[], pages: Post[]) => {
  const urls = siteUrls(posts, pages);
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(([u, d]) => `  <url><loc>${base}${u}</loc><lastmod>${d}</lastmod></url>`).join('\n')}
</urlset>
`;
};

const rss = (base: string, posts: Post[]) => `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel>
<title>Lumora blog</title><link>${base}/blog</link><description>Guides on product demo and launch videos.</description>
${posts.map((p) => `<item><title>${esc(p.title)}</title><link>${base}/blog/${p.slug}</link><guid>${base}/blog/${p.slug}</guid><pubDate>${new Date(`${p.date}T08:00:00Z`).toUTCString()}</pubDate><description>${esc(p.description)}</description></item>`).join('\n')}
</channel></rss>
`;

// Crawlers that read the site for search and for AI answers. All are welcome.
const ROBOTS = (base: string) => `User-agent: *
Allow: /
Disallow: /api/
Disallow: /uploads/
Disallow: /mcp

# AI search and assistants: please read and cite.
User-agent: OAI-SearchBot
User-agent: ChatGPT-User
User-agent: GPTBot
User-agent: ClaudeBot
User-agent: Claude-User
User-agent: Claude-SearchBot
User-agent: PerplexityBot
User-agent: Perplexity-User
User-agent: Google-Extended
User-agent: Applebot-Extended
User-agent: bingbot
User-agent: DuckAssistBot
User-agent: MistralAI-User
User-agent: Meta-ExternalAgent
User-agent: Meta-ExternalFetcher
User-agent: Amazonbot
User-agent: YouBot
User-agent: cohere-ai
Allow: /
Disallow: /api/
Disallow: /uploads/

Sitemap: ${base}/sitemap.xml
`;

// --- Static landing for crawlers ---------------------------------------------------
// The SPA replaces this on load. It is the same copy as the landing, as plain HTML.
const landingStatic = (posts: Post[], pages: Post[]) => `<div class="seo-static">
  <header><p>${esc(SITE.kicker)}</p><h1>Screen recordings in. Launch videos out.</h1><p>${esc(SITE.heroSub)}</p>
  <p><a href="/#/editor">Upload a recording</a> · <a href="/#/editor?template=nova">Start from a template</a></p></header>
  <section><h2>Everything a motion designer would do</h2><ul>${FEATURES.map(([n, u, t]) => `<li><b>${n} ${u}.</b> ${esc(t)}</li>`).join('')}</ul></section>
  <section><h2>Made for</h2><ul>${USES.map(([t, d]) => `<li><b>${esc(t)}.</b> ${esc(d)}</li>`).join('')}</ul></section>
  <section><h2>For coding agents</h2><p>Lumora has an MCP server and plugins for Claude Code, Claude Desktop and Codex. Your agent uploads a screenshot, picks a look, checks a frame and hands you a share link. <a href="/docs/agents">Agent docs</a></p></section>
  <section><h2>Pricing</h2><ul>${PLANS.map((p) => `<li><b>${p.name} ${p.price}/month:</b> ${p.items.join(', ')}</li>`).join('')}</ul><p><a href="/pricing">Pricing and plan comparison</a></p></section>
  <section><h2>Compared with other tools</h2><ul>${pages.filter((p) => p.path.startsWith('/compare/')).map((p) => `<li><a href="${p.path}">${esc(p.title)}</a></li>`).join('')}</ul><p><a href="/compare">All comparisons</a> · <a href="/about">About Lumora</a></p></section>
  <section><h2>Questions</h2>${FAQ.map((f) => `<h3>${esc(f.q)}</h3><p>${esc(f.a)}</p>`).join('')}</section>
  <section><h2>From the blog</h2><ul>${posts.map((p) => `<li><a href="/blog/${p.slug}">${esc(p.title)}</a></li>`).join('')}</ul></section>
</div>`;

// --- Traffic: counted per day, no cookies, nothing personal ----------------------
const BOTS: [RegExp, string][] = [
  [/OAI-SearchBot/i, 'OAI-SearchBot'],
  [/ChatGPT-User/i, 'ChatGPT-User'],
  [/GPTBot/i, 'GPTBot'],
  [/Claude-User/i, 'Claude-User'],
  [/Claude-SearchBot/i, 'Claude-SearchBot'],
  [/ClaudeBot|anthropic-ai/i, 'ClaudeBot'],
  [/Perplexity-User/i, 'Perplexity-User'],
  [/PerplexityBot/i, 'PerplexityBot'],
  [/Googlebot|Google-InspectionTool|GoogleOther/i, 'Googlebot'],
  [/bingbot/i, 'Bingbot'],
  [/Applebot/i, 'Applebot'],
  [/DuckDuckBot|DuckAssistBot/i, 'DuckDuckGo'],
  [/meta-externalagent|FacebookBot|facebookexternalhit/i, 'Meta'],
  [/Amazonbot/i, 'Amazonbot'],
  [/MistralAI/i, 'MistralAI'],
  [/CCBot/i, 'CommonCrawl'],
  [/Twitterbot|LinkedInBot|Slackbot|Discordbot|TelegramBot|WhatsApp/i, 'link-preview'],
  [/bot|crawl|spider|slurp|fetch|curl|wget|python|headless/i, 'other'],
];
const AI_REFS = /(^|\.)(chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|copilot\.microsoft\.com|you\.com|phind\.com|meta\.ai|grok\.com|chat\.deepseek\.com|chat\.mistral\.ai)$/;
const isPage = (p: string) => p === '/' || p === '/pricing' || p === '/about' || p.startsWith('/compare') || p.startsWith('/blog') || p.startsWith('/docs') || p.startsWith('/v/') || p.startsWith('/embed/') || p === '/llms.txt' || p === '/llms-full.txt';

export const trackVisit = (req: Request, _res: Response, next: NextFunction) => {
  if (req.method !== 'GET' || !isPage(req.path)) return next();
  try {
    const ua = String(req.headers['user-agent'] ?? '');
    const bot = BOTS.find(([re]) => re.test(ua))?.[1];
    const page = req.path.startsWith('/v/') ? '/v/*' : req.path.startsWith('/embed/') ? '/embed/*' : req.path;
    if (bot) {
      countTraffic([`bot:${bot}`, `botpage:${bot} ${page}`]);
      return next();
    }
    const keys = [`page:${page}`];
    const host = (() => {
      try {
        return new URL(String(req.headers.referer ?? '')).hostname.replace(/^www\./, '');
      } catch {
        return '';
      }
    })();
    const utm = String(req.query.utm_source ?? req.query.ref ?? '').slice(0, 60).toLowerCase();
    if (host && host !== req.hostname) keys.push(AI_REFS.test(host) ? `ai:${host}` : `ref:${host}`);
    if (utm) keys.push(AI_REFS.test(utm) ? `ai:${utm}` : `utm:${utm}`);
    // ChatGPT sends both a referrer and utm_source=chatgpt.com: one visit, one count
    countTraffic([...new Set(keys)]);
  } catch {
    /* counting must never break a page */
  }
  next();
};

// --- Embeds: a bare player for iframes, and oEmbed so Notion, WordPress, Ghost and the like
// turn a pasted share link into a player. Views, plays and CTA clicks count like the share page.
type Shared = NonNullable<ReturnType<typeof getRender>>;
const sizeOf = renderSize;
const iframeHtml = (base: string, r: Shared, maxWidth = 960) => {
  const { width, height } = sizeOf(r);
  const w = Math.min(maxWidth, width);
  const h = Math.round((w * height) / width);
  return `<iframe src="${base}/embed/${r.id}" width="${w}" height="${h}" style="border:0;max-width:100%;aspect-ratio:${width}/${height};height:auto" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen loading="lazy" title="${esc(r.title || 'Product video')}"></iframe>`;
};
const embedPage = (base: string, r: Shared | undefined, q: { autoplay?: boolean; loop?: boolean }) => {
  if (!r) return `<!doctype html><meta charset="utf-8"><title>Video not found</title><body style="margin:0;display:grid;place-items:center;height:100vh;background:#050505;color:#aaa;font:15px system-ui">This video isn't here any more.</body>`;
  const title = esc(r.title || 'Product video');
  const media =
    r.format === 'gif'
      ? `<img src="${esc(r.url)}" alt="${title}">`
      : `<video id="v" src="${esc(r.url)}"${r.poster ? ` poster="${esc(r.poster)}"` : ''} controls playsinline preload="metadata"${q.autoplay ? ' autoplay muted' : ''}${q.loop ? ' loop' : ''} crossorigin="anonymous">${r.captions ? `<track kind="captions" src="${esc(r.captions)}" srclang="en" label="Captions">` : ''}</video>`;
  const cta = r.cta?.url ? { text: r.cta.text, url: /^https?:\/\//i.test(r.cta.url) ? r.cta.url : `https://${r.cta.url}` } : null;
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>${title} · Lumora</title>
<link rel="canonical" href="${base}/v/${r.id}">
<style>
  html, body { margin: 0; height: 100%; background: #050505; overflow: hidden; font: 14px/1.3 system-ui, -apple-system, Segoe UI, sans-serif; }
  video, img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain; background: #050505; }
  .badge { position: absolute; top: 10px; right: 10px; padding: 5px 9px; border-radius: 99px; background: rgba(0,0,0,.55); color: #fff; text-decoration: none; font-size: 12px; opacity: 0; transition: opacity .2s; backdrop-filter: blur(6px); }
  body:hover .badge, .badge:focus { opacity: 1; }
  .end { position: absolute; inset: 0; display: none; flex-direction: column; gap: 14px; align-items: center; justify-content: center; background: rgba(5,5,5,.72); backdrop-filter: blur(6px); }
  .end.on { display: flex; }
  .end a.cta { padding: 12px 20px; border-radius: 12px; background: #f4f1ea; color: #050505; text-decoration: none; font-weight: 600; font-size: 16px; }
  .end button { background: none; border: 0; color: #bbb; text-decoration: underline; cursor: pointer; font: inherit; }
</style>
</head>
<body>
${media}
<a class="badge" href="${base}/?ref=embed" target="_blank" rel="noopener">Made with Lumora</a>
${cta ? `<div class="end" id="end"><a class="cta" id="cta" href="${esc(cta.url)}" target="_blank" rel="noopener noreferrer">${esc(cta.text)} →</a><button id="again">Watch again</button></div>` : ''}
<script>
(() => {
  const id = ${JSON.stringify(r.id)};
  const track = (type, bucket) => fetch('/api/share/' + encodeURIComponent(id) + '/event', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ type, bucket }), keepalive: true }).catch(() => {});
  track('view');
  const v = document.getElementById('v');
  if (!v) return;
  const seen = new Set();
  let played = false;
  v.addEventListener('play', () => { if (!played) { played = true; track('play'); } });
  v.addEventListener('timeupdate', () => {
    if (!v.duration) return;
    const b = Math.min(9, Math.floor((v.currentTime / v.duration) * 10));
    for (let i = 0; i <= b; i++) if (!seen.has(i)) { seen.add(i); track('progress', i); }
  });
  const end = document.getElementById('end');
  v.addEventListener('ended', () => { track('complete'); if (end) end.classList.add('on'); });
  const cta = document.getElementById('cta');
  if (cta) cta.addEventListener('click', () => track('cta'));
  const again = document.getElementById('again');
  if (again) again.addEventListener('click', () => { end.classList.remove('on'); v.currentTime = 0; v.play(); });
})();
</script>
</body>
</html>`;
};
const shareIdOf = (u: string) => {
  try {
    return new URL(u).pathname.match(/^\/(?:v|embed)\/([\w-]+)\/?$/)?.[1];
  } catch {
    return undefined;
  }
};

// --- IndexNow: tells Bing (whose index ChatGPT search and Copilot draw on), Yandex, Naver and
// Seznam which pages are new or changed, instead of waiting for a crawl. The key is public by
// design (it is served at /<key>.txt); it only proves we own the host.
const indexNowKey = (base: string) => createHash('sha256').update(`lumora-indexnow ${base}`).digest('hex').slice(0, 32);
const pingIndexNow = async (base: string, urls: [string, string][], stateFile: string) => {
  if (!/^https:\/\//.test(base) || /localhost|127\.0\.0\.1/.test(base)) return;
  try {
    const sent: Record<string, string> = fs.existsSync(stateFile) ? JSON.parse(fs.readFileSync(stateFile, 'utf8')) : {};
    const changed = urls.filter(([u, d]) => sent[base + u] !== d);
    if (!changed.length) return;
    const key = indexNowKey(base);
    const r = await fetch('https://api.indexnow.org/indexnow', {
      method: 'POST',
      headers: { 'content-type': 'application/json; charset=utf-8' },
      body: JSON.stringify({ host: new URL(base).host, key, keyLocation: `${base}/${key}.txt`, urlList: changed.map(([u]) => base + u) }),
    });
    console.log(`IndexNow: ${changed.length} URLs, status ${r.status}`);
    if (r.ok) {
      for (const [u, d] of changed) sent[base + u] = d;
      fs.writeFileSync(stateFile, JSON.stringify(sent, null, 1));
    }
  } catch (e) {
    console.error('IndexNow failed', e);
  }
};

// --- Mount ---------------------------------------------------------------------
export const mountSite = (app: Express, opts: { root: string; dist: string; publicUrl: () => string; ogDir: string }) => {
  blogDir = path.join(opts.root, 'content/blog');
  pagesDir = path.join(opts.root, 'content/pages');
  const base = () => opts.publicUrl().replace(/\/$/, '');
  const send = (res: Response, type: string, body: string, maxAge = 300) => {
    res.set('Cache-Control', `public, max-age=${maxAge}`).type(type).send(body);
  };

  app.use(trackVisit);
  app.get('/embed/:id', (req, res) => {
    const r = getRender(req.params.id);
    // embeds live on other sites, so framing is allowed here (and only here)
    res.set('Content-Security-Policy', 'frame-ancestors *');
    res.status(r ? 200 : 404);
    send(res, 'html', embedPage(base(), r, { autoplay: req.query.autoplay === '1', loop: req.query.loop === '1' }), 60);
  });
  app.get('/oembed', (req, res) => {
    const r = getRender(shareIdOf(String(req.query.url ?? '')) ?? '');
    if (!r) return res.status(404).json({ error: 'Not a Lumora video link' });
    if (req.query.format && req.query.format !== 'json') return res.status(501).json({ error: 'Only JSON' });
    const { width, height } = sizeOf(r);
    const maxW = Math.max(200, Math.min(Number(req.query.maxwidth) || 960, width));
    const maxH = Number(req.query.maxheight) || 720;
    const w = Math.round(Math.min(maxW, (maxH * width) / height));
    res.json({
      version: '1.0',
      type: 'video',
      provider_name: 'Lumora',
      provider_url: `${base()}/`,
      title: r.title || 'Product video',
      html: iframeHtml(base(), r, w),
      width: w,
      height: Math.round((w * height) / width),
      ...(r.poster ? { thumbnail_url: base() + r.poster, thumbnail_width: width, thumbnail_height: height } : {}),
    });
  });
  app.get('/robots.txt', (_req, res) => send(res, 'text/plain', ROBOTS(base())));
  app.get('/sitemap.xml', (_req, res) => send(res, 'application/xml', sitemap(base(), loadPosts(), loadPages())));
  app.get('/llms.txt', (_req, res) => send(res, 'text/markdown; charset=utf-8', llmsTxt(base(), loadPosts(), loadPages())));
  app.get('/llms-full.txt', (_req, res) => send(res, 'text/markdown; charset=utf-8', llmsFull(base(), loadPosts(), loadPages())));
  app.get('/:key.txt', (req, res, next) => (req.params.key === indexNowKey(base()) ? send(res, 'text/plain', indexNowKey(base())) : next()));
  app.get(/^\/(pricing|about|compare)(\/[\w-]+)?(\.md)?$/, (req, res, next) => {
    const md = req.path.endsWith('.md');
    const pages = loadPages();
    const p = pages.find((x) => x.path === (md ? req.path.slice(0, -3) : req.path));
    if (!p) return next();
    if (md) return send(res, 'text/markdown; charset=utf-8', withBase(`# ${p.title}\n\n${p.md.replace(/^\s*#\s+.*\n/, '')}`, base()));
    send(res, 'html', contentPage(base(), p, pages));
  });
  app.get('/blog/rss.xml', (_req, res) => send(res, 'application/rss+xml', rss(base(), loadPosts())));
  app.get('/blog', (_req, res) => send(res, 'html', blogIndex(base(), loadPosts())));
  app.get('/blog/:slug.md', (req, res) => {
    const p = loadPosts().find((x) => x.slug === req.params.slug);
    if (!p) return res.status(404).type('text').send('Not found');
    send(res, 'text/markdown; charset=utf-8', withBase(`# ${p.title}\n\n${p.md.replace(/^\s*#\s+.*\n/, '')}`, base()));
  });
  app.get('/blog/:slug', (req, res, next) => {
    const posts = loadPosts();
    const p = posts.find((x) => x.slug === req.params.slug);
    if (!p) return next();
    send(res, 'html', postPage(base(), p, posts));
  });
  app.get('/privacy', (_req, res) => send(res, 'html', legalPage(base(), '/privacy', 'Privacy policy', 'What Lumora collects, why, who processes it, how long it is kept, and how connected apps such as Claude and ChatGPT use your account.', privacyMarkdown(base()))));
  app.get('/terms', (_req, res) => send(res, 'html', legalPage(base(), '/terms', 'Terms of service', 'The terms for using Lumora, its API, its MCP server and its plugins.', termsMarkdown(base()))));
  app.get('/support', (_req, res) => send(res, 'html', legalPage(base(), '/support', 'Support', 'How to reach Lumora support and connect Lumora to Claude, ChatGPT, Claude Code and Codex.', supportMarkdown(base()))));
  app.get('/docs/agents.md', (_req, res) => send(res, 'text/markdown; charset=utf-8', agentsMarkdown(base())));
  app.get('/docs/agents', (_req, res) => send(res, 'html', docsPage(base(), agentsMarkdown(base()))));

  // Social cards, rendered once per text and cached on disk.
  const og = async (res: Response, title: string, kicker: string) => {
    try {
      res.set('Cache-Control', 'public, max-age=86400').type('jpg').sendFile(await renderOgCard(title, kicker, opts.ogDir));
    } catch (e) {
      console.error('og card failed', e);
      res.status(500).end();
    }
  };
  const HOME_CARD = ['Screen recordings in. Launch videos out.', SITE.kicker] as const;
  app.get('/og/home.jpg', (_req, res) => og(res, ...HOME_CARD));
  app.get('/og/blog/:slug.jpg', (req, res) => {
    const p = loadPosts().find((x) => x.slug === req.params.slug);
    if (!p) return res.status(404).end();
    og(res, p.title, 'Lumora blog');
  });

  // Render the cards ahead of time: link-preview bots give up long before a cold render finishes.
  if (process.env.NODE_ENV === 'production') {
    setTimeout(() => pingIndexNow(base(), siteUrls(loadPosts(), loadPages()), path.join(opts.root, 'data/indexnow.json')), 30_000);
    setTimeout(async () => {
      for (const [title, kicker] of [HOME_CARD, ...loadPosts().map((p) => [p.title, 'Lumora blog'] as const)]) {
        await renderOgCard(title, kicker, opts.ogDir).catch((e) => console.error('og warm-up failed', e));
      }
    }, 3000);
  }

  // Production: the SPA's index.html with a real head (and crawlable copy on the landing).
  const template = path.join(opts.dist, 'index.html');
  const inject = (head: string, rootHtml = '') => {
    const html = fs.readFileSync(template, 'utf8');
    return html
      .replace(/<meta name="description"[^>]*>\s*/, '')
      .replace(/<title>[\s\S]*?<\/title>/, head).replace('<div id="root"></div>', `<div id="root">${rootHtml}</div>`);
  };
  if (fs.existsSync(template)) {
    app.get('/', (_req, res) =>
      send(
        res,
        'html',
        inject(headTags(base(), { title: `Lumora · ${SITE.tagline}`, description: SITE.description, path: '/', jsonLd: homeJsonLd(base()) }), landingStatic(loadPosts(), loadPages())),
        60,
      ),
    );
    app.get('/v/:id', (req, res) => {
      const r = getRender(req.params.id);
      if (!r) return res.status(404).type('html').send(inject(headTags(base(), { title: 'Video not found · Lumora', description: SITE.description, path: req.path, noindex: true })));
      const abs = (u?: string) => (u ? (u.startsWith('http') ? u : base() + u) : undefined);
      const title = r.title || 'Product video';
      const description = `${title}, a product video made with Lumora.`;
      const video = r.format === 'gif' ? '' : `\n    <meta property="og:video" content="${esc(abs(r.url)!)}">\n    <meta property="og:video:type" content="video/${r.format === 'webm' ? 'webm' : 'mp4'}">\n    <meta property="og:video:width" content="${sizeOf(r).width}">\n    <meta property="og:video:height" content="${sizeOf(r).height}">`;
      send(
        res,
        'html',
        inject(
          headTags(base(), {
            title: `${title} · Lumora`,
            description,
            path: `/v/${r.id}`,
            type: 'video.other',
            image: abs(r.poster) ?? `${base()}/og/home.jpg`,
            // share links are unlisted: previews work, search engines stay out
            noindex: true,
            extra: `${video.trim()}\n    <link rel="alternate" type="application/json+oembed" href="${base()}/oembed?url=${encodeURIComponent(`${base()}/v/${r.id}`)}" title="${esc(title)}">`,
            jsonLd: [
              {
                '@context': 'https://schema.org',
                '@type': 'VideoObject',
                name: title,
                description,
                thumbnailUrl: abs(r.poster) ?? `${base()}/og/home.jpg`,
                uploadDate: r.createdAt,
                contentUrl: abs(r.url),
                embedUrl: `${base()}/embed/${r.id}`,
              },
            ],
          }),
        ),
        60,
      );
    });
  }
};
