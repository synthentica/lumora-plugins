# Verified facts and sources

Every fact used in the blog posts is listed here, with its primary source. Status: checked 2026-10-17 by fetching the page, unless marked otherwise. Prices and limits change, so re-check before republishing.

## Product Hunt

| Fact | Source | Checked |
|---|---|---|
| Thumbnail: square, "We recommend 240x240" | https://help.producthunt.com/en/articles/479557-how-to-post-a-product | checked 2026-10-17 |
| Thumbnail GIF must be under 3MB and not too "flashy". It animates only on hover, so the first frame is the static view | https://help.producthunt.com/en/articles/479557-how-to-post-a-product | checked 2026-10-17 |
| "All images, GIF or not, need to be under 3MB" (this sentence is under the thumbnail heading, so it is unclear whether it applies to gallery images) | https://www.producthunt.com/launch/preparing-for-launch | checked 2026-10-17 |
| Avoid GIFs with "strobing effects, quick cuts, unreadable text". Product Hunt may edit them | https://www.producthunt.com/launch/preparing-for-launch | checked 2026-10-17 |
| "Less than a third of Product of the Day products used an animated GIF as a thumbnail" | https://www.producthunt.com/launch/preparing-for-launch | checked 2026-10-17 |
| Gallery: recommended image size 1270x760. Needs 2+ images before it shows. Images can be reordered by drag | https://help.producthunt.com/en/articles/479557-how-to-post-a-product | checked 2026-10-17 |
| Gallery can use animated GIFs | https://www.producthunt.com/launch/preparing-for-launch | checked 2026-10-17 |
| Video is optional. Only YouTube links are supported. The video must not be private, and you must use the full URL (shortened links won't load) | https://help.producthunt.com/en/articles/5473122-how-to-post-media | checked 2026-10-17 |
| "About 53% of products that reached Product of the Day since 2021 include a video" | https://www.producthunt.com/launch/preparing-for-launch | checked 2026-10-17 |
| No video length guidance is given by Product Hunt | https://help.producthunt.com/en/articles/5473122-how-to-post-media | checked 2026-10-17 |
| Interactive demo tools Product Hunt names: Arcade, Storylane, Hexus, Supademo, Layerpath, ScreenSpace. Their links can be added to the gallery like a YouTube link | https://www.producthunt.com/launch/preparing-for-launch | checked 2026-10-17 |
| Quick demo with a tool like Loom "can go a long way" if there is no budget for a high-end video | https://www.producthunt.com/launch/preparing-for-launch | checked 2026-10-17 |

## YouTube

| Fact | Source | Checked |
|---|---|---|
| Standard aspect ratio on computer is 16:9. 1080p = 1920x1080 | https://support.google.com/youtube/answer/6375112?hl=en&co=GENIE.Platform%3DDesktop | checked 2026-10-17 |
| Vertical 9:16 videos on desktop get padding. "Avoid adding padding or black bars directly to your video" | https://support.google.com/youtube/answer/6375112?hl=en&co=GENIE.Platform%3DDesktop | checked 2026-10-17 |
| Recommended upload: MP4 container, H.264 codec, same frame rate as recorded | https://support.google.com/youtube/answer/1722171?hl=en | checked 2026-10-17 |
| 1080p SDR bitrate: 8 Mbps (24–30 fps), 12 Mbps (48–60 fps) | https://support.google.com/youtube/answer/1722171?hl=en | checked 2026-10-17 |
| Audio: AAC-LC (or Opus), stereo 384 kbps | https://support.google.com/youtube/answer/1722171?hl=en | checked 2026-10-17 |
| Shorts can be up to 3 minutes and need a square or vertical aspect ratio (for uploads on or after Oct 15, 2024) | https://support.google.com/youtube/answer/15424877?hl=en | checked 2026-10-17 |

## X (Twitter)

| Fact | Source | Checked |
|---|---|---|
| Regular accounts (web): videos up to 140 seconds, max 512MB | https://help.x.com/en/using-x/x-videos | checked 2026-10-17 |
| Premium subscribers: up to 4 hours at 1080p, max 16GB (web) | https://help.x.com/en/using-x/x-videos | checked 2026-10-17 |
| API video guidance: H264 High Profile, 60 fps or less, aspect ratio between 1:3 and 3:1, at least 0.5 s. Resolution 32x32 to 1280x1024; subscribed users can upload 1080p | https://docs.x.com/x-api/media/quickstart/best-practices | checked 2026-10-17 |
| Animated GIF (API): 15MB or less, 350 frames or less, 1280x1080 or less | https://docs.x.com/x-api/media/quickstart/best-practices | checked 2026-10-17 |
| Note: the help page (140 s / 512MB) and API docs (20 min / 8GB default) give different limits. The posts use the help-page figures for normal web posting | both above | checked 2026-10-17 |

## LinkedIn

| Fact | Source | Checked |
|---|---|---|
| Video ads: MP4. 75 KB to 500 MB. 3 s to 30 min. 30 fps recommended. Captions optional | https://business.linkedin.com/advertise/ads/sponsored-content/video-ads/specs | checked 2026-10-17 |
| Video ads aspect ratios and max sizes: 16:9 up to 1920x1080; 1:1 up to 1920x1920; 9:16 up to 1080x1920; 4:5 up to 1080x1350 | https://business.linkedin.com/advertise/ads/sponsored-content/video-ads/specs | checked 2026-10-17 |
| Videos API: length 3 s to 30 min. File size 75 KB to 500 MB. MP4. One caption file per video (SRT in the example). Note: the same page's `fileSizeBytes` field says 5GB max, which conflicts | https://learn.microsoft.com/en-us/linkedin/marketing/community-management/shares/videos-api?view=li-lms-2026-05 | checked 2026-10-17 |
| NOT VERIFIED: LinkedIn's organic-post help page (linkedin.com/help/linkedin/answer/a548372). It blocks automated fetching, so organic limits (often quoted as 5GB / 15 min desktop / 10 min mobile) are not used in the posts | — | could not fetch |

## GitHub

| Fact | Source | Checked |
|---|---|---|
| Attachments: 10MB for images and GIFs. Videos 10MB on free plans, 100MB on paid plans. Video formats .mp4, .mov, .webm | https://docs.github.com/en/get-started/writing-on-github/working-with-advanced-formatting/attaching-files | checked 2026-10-17 |
| You can attach files to issues, pull requests and comments (the doc does not mention READMEs) | https://docs.github.com/en/get-started/writing-on-github/working-with-advanced-formatting/attaching-files | checked 2026-10-17 |
| Files added via browser: max 25 MiB. Git warns above 50 MiB. Files over 100 MiB are blocked | https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github | checked 2026-10-17 |

## Engagement data

| Fact | Source | Checked |
|---|---|---|
| Wistia: "Videos under a minute average a 52% engagement rate" (engagement = share of the video watched). Product videos 50%. Wistia's data is from its 2026 State of Video Report (body says 13M+ videos analysed; the meta description says 100M, so the dataset size is inconsistent and is not quoted) | https://wistia.com/blog/optimal-video-length | checked 2026-10-17 |

## Competitors

| Fact | Source | Checked |
|---|---|---|
| Screen Studio: macOS only ("Currently, Screen Studio only supports macOS"). macOS 13.1+ recommended. Has auto zoom on clicks and cursor smoothing | https://screen.studio/ | checked 2026-10-17 |
| Screen Studio pricing: Yearly plan "$9/mo.", Monthly plan "$29/mo." | https://screen.studio/ (pricing section) | checked 2026-10-17 |
| Screen Studio Windows request on its feedback board is "In Review", with no team reply | https://hub.screen.studio/p/windows-version | checked 2026-10-17 |
| Cap: open source. macOS, Windows, Linux (.deb). Free for personal use (5-min cloud links). Desktop License $58 one-time or $29/yr. Pro $12/user/mo ($8.16 billed annually). Auto zoom from recorded clicks (Studio Mode) | https://cap.so/ | checked 2026-10-17 |
| Screenity: Chrome extension, free, open source (GPLv3). Turns clicks into zooms. Paid editor/sharing plan $10/mo or $120/yr, 7-day trial | https://screenity.io/ | checked 2026-10-17 |
| Tella: Chrome extension, native macOS and Windows recorders. Pro $13/mo, Premium $19/mo (billed annually) | https://www.tella.com/pricing | checked 2026-10-17 |
| Tella claims auto-zoom, custom backgrounds and smooth cursor motion (vendor claim) | https://www.tella.com/screen-studio-alternative | checked 2026-10-17 |
| FocuSee: Windows and macOS. Auto zoom on clicks and typing. Pricing not on the homepage, so it is not quoted | https://focusee.imobie.com/ and https://focusee.imobie.com/features/auto-zoom-and-cursor-animation.htm | checked 2026-10-17 |
| Screenhance: browser-based (Chromium on macOS, Windows, Linux, ChromeOS). Records screen/camera. Zooms, device frames, captions. MP4/WebM. Free with watermark. Pro $12/mo or $99/yr. Zooms placed manually (the extension captures click data to guide them) | https://screenhance.com/screen-studio-alternative | checked 2026-10-17 |
| Camtasia: Windows 10 & 11 and macOS 14+. Plans per year: Starter $39, Essentials $179.88, Create $249, Pro $599 | https://www.techsmith.com/store/camtasia | checked 2026-10-17 |
| ngram: changelog/release-notes-to-video product with API and MCP server (competitor, not named in posts) | https://www.ngram.com/use-cases/changelog-video | checked 2026-10-17 |

## Agents / MCP

| Fact | Source | Checked |
|---|---|---|
| MCP standard transports: stdio and Streamable HTTP (each message is an HTTP POST to a single MCP endpoint) | https://modelcontextprotocol.io/specification/draft/basic/transports | checked 2026-10-17 |
| Claude Code: `claude mcp add --transport http <name> <url> --header "Authorization: Bearer ..."`. Scopes local (default), project (`.mcp.json`), user. SSE transport is deprecated | https://code.claude.com/docs/en/mcp | checked 2026-10-17 |
| Codex: `[mcp_servers.<name>]` table in `~/.codex/config.toml`. `url` is required. `bearer_token_env_var` names an env var sent as `Authorization` bearer | https://learn.chatgpt.com/docs/extend/mcp?surface=cli (redirect from developers.openai.com/codex/mcp) | checked 2026-10-17 |

## Lumora facts (internal: from the product brief and repo, not web sources)

| Fact | Source |
|---|---|
| MCP tools: list_styles, upload_media, create_video, update_video, get_video, list_videos, preview_frame, render_video (mp4/gif/webm), render_status | `mcp/src/tools.ts`, coordinator brief |
| `create_video` spec fields: name, media{url,kind,slides}, brief, title, tagline, intro, look, camera, palette, colors, effects, format, duration (5–60 s), callouts, zooms, music, script, voice, captions (pop/clean/karaoke/off), device (macbook/ipad/none), cta{text,url} | `mcp/src/tools.ts` |
| `format` accepts `landscape`, `vertical`, `square` (the server rejects `"16:9"` with "Use landscape, vertical or square") | `server/videos.ts` line 131 |
| Hosted MCP endpoint at `/mcp` with Bearer API key | `mcp/README.md`, coordinator brief |
| No published npm package. Do not reference `npx lumora-mcp` | coordinator instruction |
| Export: 16:9 = 1920x1080, 9:16 = 1080x1920, 1:1 = 1080x1080 at 30 fps H.264 + AAC on paid plans | `README.md` |

## Added 2026-10-25 (comparison pages and "best product demo video software")

| Fact | Source | Checked |
|---|---|---|
| Screen Studio: Yearly "$9/mo." ("Save 69%"), Monthly "$29/mo.". macOS only. Auto zoom from clicks; captions generated locally; MP4 720p/1080p/4K up to 60 fps, GIF up to 1080p; AI voice from typed script; iPhone over USB | https://screen.studio/ | checked 2026-10-25 |
| Tella: Pro $13, Premium $19 per user/month billed annually; no free plan listed, trials mentioned. Mac, Windows, browser. Separate screen/camera tracks, layouts, auto zoom, subtitles, transcript editing (filler words, silences), audio cleanup, 4K 60 fps download, viewer analytics, clips up to 6 hours | https://www.tella.com/pricing and https://www.tella.com/ | checked 2026-10-25 |
| Arcade: Free $0 with 250 one-time credits, videos up to 30 s, 1080p exports, watermark. Pro $49/month billed annually (1,000 credits). Enterprise custom. AI video from an idea (launch, changelog, talking head, how-to, article to video), interactive demos, Chrome extension capture, Arcade MCP for Claude and ChatGPT | https://www.arcade.software/pricing and https://www.arcade.software/ | checked 2026-10-25 |
| Supademo: Free (5 interactive demos, 50 video recordings, video up to 1080p with watermark). Scale $38/month with $50 shown struck through ("Save 24%"). AI voiceovers from Scale up | https://supademo.com/pricing | checked 2026-10-25 |
| Name clash: "Lumora" at uselumora.app is an interactive click-through demo tool (Chrome extension "Lumora Recorder", 14 users, updated 9 Mar 2026; G2 listing in Demo Automation Software). Free / Starter $29 / Growth $79 | https://uselumora.app/, Chrome Web Store, https://www.g2.com/products/lumora/discuss | checked 2026-10-25 |

## Added 2026-10-27 (posts: demo video from screenshots, video length, camera moves, landing page hero video)

| Fact | Source | Checked |
|---|---|---|
| App previews: 15 s minimum, 30 s maximum; up to three per device size and language; .mov/.m4v/.mp4 (H.264) or ProRes 422 HQ; max 30 fps; max 500MB | https://www.developer.apple.com/help/app-store-connect/reference/app-information/app-preview-specifications | checked 2026-10-27 |
| Google Play preview video: one YouTube URL; public or unlisted; ads disabled; not age-restricted; embeddable. "May autoplay inline with muted audio up to 30 seconds"; "only the first 30 seconds autoplays". Show the app "within the first 10 seconds"; aim for 80% representative footage; use captions | https://support.google.com/googleplay/android-developer/answer/9866151?hl=en | checked 2026-10-27 |
| LinkedIn video ad tips: "7–15 second videos seeing up to a 300% lift in completion rates" (LinkedIn data, 2025); show what matters in the first 10 seconds; "establish your point in the first 5 seconds"; "think like a silent film director"; consider burned-in subtitles | https://business.linkedin.com/advertise/ads/sponsored-content/video-ads/tips?ss=1 | checked 2026-10-27 |
| Vidyard 2025 Video in Business Benchmark Report (943,305 videos created by customers in 2024): under 1 min, 65% of viewers stay to the end; over 20 min, 20%; engagement drops at every runtime milestone; highest in the first quarter | https://www.vidyard.com/video-benchmark/ | checked 2026-10-27 |
| Instagram Reels up to 3 minutes (from 90 s), announced by Adam Mosseri on 18 Jan 2025 (secondary source; Instagram's own help page not fetched) | https://www.socialmediatoday.com/news/instagram-officially-expands-reels-length-to-3-minutes/737766/ | checked 2026-10-27 |
| Comfortable presentation pace 100–150 words per minute (VirtualSpeech; no primary source cited for this range) | https://virtualspeech.com/blog/average-speaking-rate-words-per- | checked 2026-10-27 |
| Chrome: "Muted autoplay is always allowed." Autoplay with sound needs user interaction, a high Media Engagement Index (desktop) or an installed site | https://developer.chrome.com/blog/autoplay | checked 2026-10-27 |
| iOS (since iOS 10): muted videos or videos without audio tracks may autoplay; playsinline plays inline on iPhone; autoplaying videos pause when scrolled out of view; a video that gains audio or is unmuted without a gesture pauses | https://webkit.org/blog/6784/ | checked 2026-10-27 |
| iOS Low Power Mode blocking autoplay: reported by developers in WebKit bug 216887 (status NEW); no official confirmation | https://bugs.webkit.org/show_bug.cgi?id=216887 | checked 2026-10-27 |
| MDN video: poster is shown while the video downloads; preload none/metadata/auto is a hint, default differs per browser, spec advises metadata; playsinline; muted | https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/video | checked 2026-10-27 |
| web.dev: example GIF 3.7 MB → MP4 551 KB → WebM 341 KB; use `<video autoplay loop muted playsinline>` with WebM then MP4 sources; browsers pick the first playable source | https://web.dev/articles/replace-gifs-with-videos | checked 2026-10-27 |
| web.dev LCP: for video, the earlier of poster image load or first frame counts; good LCP ≤ 2.5 s | https://web.dev/articles/lcp | checked 2026-10-27 |
| web.dev prefers-reduced-motion: `reduce` means minimise non-essential motion; "refraining from having autoplaying videos" is one way to respect it | https://web.dev/articles/prefers-reduced-motion | checked 2026-10-27 |
| WCAG 2.2 SC 2.2.2 Pause, Stop, Hide (Level A): moving content that starts automatically, lasts more than five seconds and is shown with other content needs a way to pause, stop or hide it | https://www.w3.org/WAI/WCAG22/Understanding/pause-stop-hide | checked 2026-10-27 |
| ffmpeg mov/mp4 `-movflags faststart`: "Run a second pass moving the index (moov atom) to the beginning of the file"; not on by default | https://ffmpeg.org/ffmpeg-formats.html | checked 2026-10-27 |
| `media` attribute on `<source>` in `<video>`: back in Firefox 120 and Chrome 120 (Nov 2023); Safari never removed it (Scott Jehl, 27 Nov 2023) | https://scottjehl.com/posts/using-responsive-video/ | checked 2026-10-27 |
| Mac screenshots: Shift-Command-4 then Space for a window, Option to drop the shadow; Shift-Command-3 whole screen; Shift-Command-5 Screenshot app | https://support.apple.com/kb/ht5775 | checked 2026-10-27 |
| Windows: Windows logo key + Shift + S opens the Snipping Tool overlay; rectangle, window, full screen, freeform | https://support.microsoft.com/en-us/windows/use-snipping-tool-to-capture-screenshots-00246869-1843-655f-f220-97299b865f6b | checked 2026-10-27 |
| Chrome DevTools Command Menu: Capture screenshot / full size screenshot / node screenshot; device mode captures at the device's dimensions (Umar Hansa's DevTools tips) | https://umaar.com/dev-tips/151-screenshot-capture/ | checked 2026-10-27 |
| Keynote Magic Move "creates the effect of objects moving from their positions on one slide to new positions on the next slide" | https://support.apple.com/en-ph/guide/keynote/tanff5ae749e/mac | checked 2026-10-27 |
| NFB camera glossary (Julie Matlin, 17 Feb 2010): pan swivels sideways; tilt is a vertical pan; dolly is a wheeled platform (dolly in/out); zoom lens creates the illusion of movement; crash zoom "use with caution"; tracking; craning up and down | https://blog.nfb.ca/?p=1797 | checked 2026-10-27 |

### Our own measurement (2026-10-27)

One 7.5 s, 960x540, 30 fps loop rendered by Lumora (Closer template, Float camera), encoded with ffmpeg from the same high-quality source: WebM VP9 CRF 40 = 279,169 bytes; MP4 H.264 CRF 28 preset slow, faststart = 354,193 bytes; GIF 960 px 15 fps with palettegen/paletteuse = 15,839,786 bytes; GIF 640 px 12 fps = 7,128,062 bytes; first-frame JPEG (q 5) = 17,038 bytes. Script: scratch encode.sh in the 27 Oct blog thread.

## Added 2026-10-27, batch 2 (posts: demo video script template, App Store and Google Play previews, GitHub README GIF, device mockup videos)

| Fact | Source | Checked |
|---|---|---|
| App preview resolutions per device class: iPhone with Dynamic Island/Face ID 886x1920 (1920x886); Home-button large 1080x1920; medium 750x1334; iPad 13"/11"/10.5" 1200x1600; iPad 12.9" (2nd gen) 1200x1600 or 900x1200; iPad 9.7" 900x1200; Mac and Apple TV 1920x1080; Vision Pro 3840x2160. Audio: H.264 stereo 256 kbps AAC 44.1/48 kHz; ProRes PCM or AAC | https://www.developer.apple.com/help/app-store-connect/reference/app-information/app-preview-specifications | checked 2026-10-27 |
| Apple app preview guidelines: "show only content within the app itself"; don't film people interacting with a device; touch hotspots allowed as graphics; capture native UI resolution; dissolves and fades; no prices or timely references; disclose in-app purchase/subscription/login; rights to music; all ages; muted by default, "consider using copy"; poster frame shown when autoplay is off, changing it needs a new preview | https://developer.apple.com/support/app-previews/ | checked 2026-10-27 |
| Apple Marketing Resources and Identity Guidelines: use Apple-provided product bezels "as is"; no reflections, shadows, highlights, cropping, tilting, obstructing, "animating, flipping, or spinning"; not permitted: "Rendering in 3D or creating any simulation of an Apple product"; video: after an establishing shot of the entire device, you may pan and zoom; fictional account data | https://developer.apple.com/app-store/marketing/guidelines | checked 2026-10-27 |
| Google device art generator: wraps screenshots in device artwork for promo material; "Do not use graphics created here in your feature image or screenshots for your Google Play store listing" | https://developer.android.com/distribute/tools/promote/device-art.html | checked 2026-10-27 |
| GitHub attachments: images and GIFs 10 MB; videos 10 MB (free) / 100 MB (paid); MP4, MOV, WebM, H.264 recommended | https://docs.github.com/en/get-started/writing-on-github/working-with-advanced-formatting/attaching-files | checked 2026-10-27 |
| GitHub READMEs: content beyond 500 KiB truncated; relative links and image paths are transformed to work on every branch | https://docs.github.com/en/enterprise-server@3.19/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes | checked 2026-10-27 |
| GitHub: files added via the browser limited to 25 MiB | https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github | checked 2026-10-27 |
| GitHub video uploads generally available everywhere Markdown is supported, including repository Markdown files (13 May 2021) | https://github.blog/changelog/2021-05-13-video-uploads-now-generally-available | checked 2026-10-27 |
| GitHub `<picture>` with prefers-color-scheme sources for light/dark images | https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/quickstart-for-writing-on-github | checked 2026-10-27 |
| ffmpeg palettegen stats_mode=diff (palette from pixels that differ from previous frame); paletteuse diff_mode=rectangle (only the changed rectangle is reprocessed) | https://ffmpeg.org/ffmpeg-filters.html#palettegen | checked 2026-10-27 |

### Our own measurement: README GIF sizes (2026-10-27)

One 7.5 s Lumora clip (Shipyard sample template, slow camera move, one callout), rendered at 1920x1080 in two versions (plain dark background vs Studio photo wallpaper), encoded with ffmpeg palettegen/paletteuse. Plain / wallpaper: 1280 px 15 fps 21.3 / 29.9 MB; 960 px 15 fps 12.9 / 17.7 MB; 960 px 10 fps 9.3 / 12.4 MB; 800 px 12 fps 8.4 / 10.8 MB; 800 px 10 fps 7.2 / 9.2 MB; 640 px 10 fps 4.8 / 6.0 MB; MP4 H.264 960 px 30 fps 0.27 / 0.30 MB. stats_mode=diff + diff_mode=rectangle saved 1–25%.
